# 냥스타저장 Safari 도우미 0.2.0 — 임시 설치 안내

Instagram과 냥스타저장을 **같은 Safari 프로필**에서 사용하는 Mac용 확장 패키지다. 공통 도우미0.2.0은 Tailscale과 지정된 LAN 웹앱을 함께 지원한다. 사용자가 요청한 개별 스토리의 계정·ID·게시 시각·사진 또는 영상을 확인한다. 계정 쿠키를 읽거나 서버로 보내지 않는다. 일반 게시물과 릴스는 기존 웹앱 서버 경로를 사용한다.

다른 Mac에서 계속 사용할 설치는 [GitHub 설치 안내](https://ane1235.github.io/instadown/browser-helper/)의 Safari 프로젝트 준비 ZIP과 Xcode 설치 단계를 따른다. 아래 ZIP과 절차는 **임시 설치용**이며 서명·설치를 마친 앱이 아니다. iOS·iPadOS용 설치본이나 단축어도 아니다. 기존 Mac의 Safari 사진·영상 저장 성공과 이번0.2.0의 다른 Mac·LAN 실증은 구분하며 최신 상태는 프로젝트의 `docs/STATUS.md`를 따른다.

## Mac Safari 임시 설치

이 설치 방법에는 **macOS Safari 18.4 이상**이 필요하다. 확장 코드의 background module 최소 버전인 Safari 16.4와 별개다.

1. ZIP을 풀어 `manifest.json`이 들어 있는 `Nyangsta-Safari` 폴더를 준비한다.
2. Safari → 설정 → 고급에서 **웹 개발자를 위한 기능 보기**를 켠다.
3. 설정 → 개발자에서 **Add Temporary Extension…(임시 확장 프로그램 추가)**을 누르고 위 폴더를 선택한다. Safari가 요청하는 서명되지 않은 확장 인증은 해당 Mac 화면에서 진행한다.
4. 설정 → 확장 프로그램에서 **냥스타저장 Safari 도우미**를 켠다. 프로필을 사용한다면 Instagram에 로그인한 프로필에서도 확장을 켠다.
5. Instagram과 사용하는 냥스타저장 사이트의 접근을 Safari에서 허용한다. 같은 프로필의 Instagram 탭을 열어 로그인하고, 설치 안내에서 선택한 Tailscale 또는 LAN 웹앱을 연다. 기존 탭은 새로고침한다.
6. 연결 확인에서 **도우미 연결됨**을 확인한다. 이 확인은 Instagram 요청을 만들지 않는다. 이후 현재 볼 수 있는 개별 스토리 링크를 웹앱에 입력해 **파일 준비하기**를 누른 뒤 다운로드 링크로 저장한다.

Apple 안내에 따르면 **24시간이 지나거나 Safari를 종료하면 임시 확장이 제거**된다. 그때는 다시 임시 추가해야 한다. 계속 사용하려면 위 Xcode 프로젝트 방식으로 서명·빌드·설치한다. 확장을 수정했으면 Safari 확장 설정에서 다시 불러오고 웹앱도 새로고침한다.

## Tailscale·LAN 연결 선택

Tailscale에서는 해당 Mac을 서버에 접근 가능한 Tailscale에 연결하고 `https://kayenpc.tail730e13.ts.net:8443/`를 연다. 같은 LAN에서는 Tailscale 없이 `http://192.168.0.36:8765/`를 연다. 두 경로에 공통 패키지 하나를 쓰며 별도 서버 주소 옵션은 없다. Safari에서 새로 사용하는 웹앱 사이트의 확장 접근을 허용한다. GitHub 설치 페이지의 LAN 선택은 LAN 웹앱을 여는 방식이다. 다른 Mac의 실제 LAN 접근은 아직 별도 확인이 필요하다.

## 권한과 동작 범위

- 확장 API 권한은 `scripting` 하나이며, Instagram host 권한은 `https://www.instagram.com/*`다. `cookies`, `tabs`, `debugger`, 전체 사이트 권한을 추가하지 않는다.
- 웹앱 요청은 `https://ane1235.github.io/instadown/`, `https://kayenpc.tail730e13.ts.net:8443/`, `https://kayenpc.tail730e13.ts.net:10000/`, `http://192.168.0.36:8765/`, 개발용 `http://127.0.0.1:8765/`에서만 처리한다. manifest 패턴보다 좁게 origin·port·경로와 메시지 발신자를 코드에서 다시 확인한다. 다른 사설 IP·port·경로는 거부한다.
- 공통 JavaScript 4개는 Chrome 도우미와 동일하다. Safari 패키지 생성 시 권한·메시지 계약·발신자 검증·조회 로직을 바꾸지 않는다. 해당 브라우저가 Instagram 요청에 현재 로그인을 자동 적용한다.
- 다른 계정이나 형제 스토리를 저장하지 않는다. 429·로그인 요구·추가 인증·불명확한 접근 실패가 나면 중단하며 서버로 자동 재조회하지 않는다. 로그인·확장 권한 문제는 Safari에서 해결한 뒤 사용자가 다시 요청한다.

## 공식 근거

2026-09-19 Apple 실행·권한 안내 본문 재확인. 두 문서에는 표시 갱신일이 없으며 아래 릴리스 문서는 각각 2023-03-27, 2025-03-31 발행이다.

- [Apple: Running your Safari web extension](https://developer.apple.com/documentation/safariservices/running-your-safari-web-extension): 임시 설치 단계, 프로필별 활성화, 종료/24시간 제한.
- [Apple: Managing Safari web extension permissions](https://developer.apple.com/documentation/safariservices/managing-safari-web-extension-permissions): manifest의 사이트 범위와 Safari의 사용자 접근 허용.
- [Apple: Safari 16.4 Release Notes](https://developer.apple.com/documentation/safari-release-notes/safari-16_4-release-notes): background service worker의 module 지원.
- [WebKit: Safari 18.4](https://webkit.org/blog/16574/webkit-features-in-safari-18-4/): Xcode 프로젝트 없이 디스크에서 임시 확장을 설치하는 기능.
- [Apple: Optimizing your web extension for Safari](https://developer.apple.com/documentation/safariservices/optimizing-your-web-extension-for-safari): `browser_specific_settings.safari.strict_min_version`.
