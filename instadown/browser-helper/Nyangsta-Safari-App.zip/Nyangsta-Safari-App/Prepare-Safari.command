#!/bin/zsh
# The downloadable kit puts this launcher beside README.md and scripts/.
set -u
kit_dir="$(cd -- "$(dirname -- "$0")" && pwd -P)" || exit 1
python_path=''
for candidate in /usr/bin/python3 /opt/homebrew/bin/python3 /usr/local/bin/python3; do
    if [[ -x "$candidate" ]]; then
        python_path="$candidate"
        break
    fi
done
if [[ -z "$python_path" ]]; then
    print -r -- 'Python 3를 찾지 못했습니다. 설치한 Xcode의 초기 설정을 확인하세요.'
    result=1
else
    "$python_path" "$kit_dir/scripts/prepare-safari-local.py"
    result=$?
fi
print -r -- ''
print -r -- '이 창의 결과를 확인한 뒤 Enter를 누르면 닫힙니다.'
read -r response
exit "$result"
