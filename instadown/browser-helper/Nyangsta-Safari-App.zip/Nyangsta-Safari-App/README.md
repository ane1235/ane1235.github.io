# 냥스타저장 Safari 프로젝트 준비

이 패키지는 설치한 Xcode로 Safari 도우미의 **Mac용 프로젝트를 만들고 여는 준비 도구**입니다. 완성된 앱 설치본이 아닙니다. 프로젝트 생성 뒤 서명 설정, 빌드·설치, Safari 재시작 후 유지 확인을 이어서 진행합니다.

1. Mac에서 ZIP을 풀고 `Nyangsta-Safari-App` 폴더를 엽니다.
2. Xcode는 설치 후 한 번 실행해 초기 설정을 마친 상태여야 합니다. Mac의 Terminal에서 아래 명령을 실행합니다.
3. 터미널에 **`프로젝트 생성 완료: … .xcodeproj` 경로가 표시되고 Xcode 왼쪽에 `냥스타저장` 프로젝트가 보이는지** 확인해 알려주세요. Open / Clone / New Project만 있는 시작 화면이라면 터미널의 결과부터 확인합니다. 다음 서명·설치 단계는 프로젝트 확인 뒤 안내합니다.
4. 오류가 나오면 Terminal의 오류 문구만 알려주세요. 비밀번호, 인증서, 쿠키나 로그 전체를 보내지 마세요.

```sh
/bin/zsh "$HOME/Downloads/Nyangsta-Safari-App/Prepare-Safari.command"
```

ZIP을 다른 위치에 풀었다면 위 경로를 실제 폴더 경로로 바꾸고 큰따옴표를 유지하세요. 다운로드한 실행 파일이라 macOS가 실행을 막으면 보호 설정을 끄거나 파일 속성을 변경하지 말고, 표시된 문구를 알려주세요. Python을 찾지 못하거나 Xcode가 선택되지 않았다는 오류도 그대로 알려주세요.

생성 결과는 Mac의 `Downloads/Nyangsta-Safari-Project-날짜-시간` 폴더에 보관합니다. 같은 이름의 폴더가 있으면 숫자를 붙여 새 폴더를 사용하며 기존 파일을 덮어쓰지 않습니다. 경로에 공백이나 한글이 있어도 그대로 처리합니다. 표준 `/Applications/Xcode.app`이 있으면 이번 실행에만 사용하고, 없으면 현재 선택된 개발 도구를 사용합니다. 컴퓨터 전체의 개발 도구 설정은 바꾸지 않습니다.

준비 도구 v2는 초기 도구 확인에서 실패한 명령과 원문을 표시합니다. 도움말 명령만 종료 코드 0/64와 필수 옵션 전체를 함께 확인하며, 다른 실패를 무시하지 않습니다. 폴더가 없는 경우 Xcode에서 새 프로젝트를 만드는 대신 터미널에 표시된 실패 원인부터 확인합니다.

GitHub의 설치 안내 페이지에 게시된 준비 파일을 기존 파일과 섞이지 않게 새 폴더에 받아 실행하려면 Mac 터미널에 다음 전체를 붙여 넣습니다. 각 단계가 성공해야 다음 단계로 넘어가며 기존 파일은 보존합니다.

```sh
nyangsta_setup_dir=$(mktemp -d "$HOME/Downloads/Nyangsta-Safari-v2.XXXXXX") &&
/usr/bin/curl --fail --show-error --location 'https://ane1235.github.io/instadown/browser-helper/Nyangsta-Safari-App.zip' --output "$nyangsta_setup_dir/setup.zip" &&
/usr/bin/ditto -x -k "$nyangsta_setup_dir/setup.zip" "$nyangsta_setup_dir" &&
/bin/zsh "$nyangsta_setup_dir/Nyangsta-Safari-App/Prepare-Safari.command"
```

패키지에는 준비 스크립트와 검증에 사용한 공통 확장 소스만 포함됩니다. 준비 과정은 인터넷에서 도구를 받거나, 계정 로그인·인증서 생성·키체인 조회·서명·Safari 종료·앱 설치를 수행하지 않습니다. 결과를 서버에 자동 전송하지도 않습니다. Xcode에서 열린 프로젝트의 빌드와 서명은 다음 단계입니다.

`browser-extension/SAFARI.md`는 기존 **임시 설치** 안내입니다. 이 준비 도구로 생성하는 Xcode 프로젝트의 설치 안내와 구분하세요. 서명 없이 실행하는 확장은 Safari의 unsigned 허용 설정이 재시작 때 해제되므로 재시작 후 유지 성공으로 볼 수 없습니다. 사용자 Mac에서 실제 서명과 재시작 결과를 확인하기 전까지 지속 설치 완료로 표시하지 않습니다.

## 현재 앱 실행 검증 상태

준비 도구 v2의 Mac 프로젝트 생성은 확인했습니다. 생성 뒤 앱과 확장의 Bundle Identifier 접두어를 맞췄지만, 실제 앱 실행에서 스토리보드의 `AppDelegate`·`ViewController` 클래스와 `webView` 연결 오류가 발생해 수정 중입니다. 내부 모듈 이름을 변경한 결과와 스토리보드 참조를 함께 확인해야 하며, 이 ZIP을 다시 실행하는 것으로 기존 프로젝트의 오류가 해결되지는 않습니다. 이미 생성한 프로젝트는 보존하세요.

이 ZIP은 **서명·공증 완료 앱이 아니며**, 다른 Mac에 압축만 풀어 설치하는 배포본이 아닙니다. 앱 실행, Safari 재시작 후 유지, 다른 Mac 설치 성공은 아직 확인하지 않았습니다. 별도 Mac에서 바로 설치할 서명 앱은 이 검증을 마친 뒤 별도 파일로 안내합니다.

## 공식 근거

2026-09-18 Apple 본문 확인. 개별 문서의 갱신일은 표시되지 않았습니다.

- [Safari 확장 패키지 만들기](https://developer.apple.com/documentation/safariservices/packaging-a-web-extension-for-safari): Xcode의 packager가 Mac 앱과 확장 프로젝트를 생성합니다. 기존 converter 이름도 지원합니다.
- [Safari 확장 실행](https://developer.apple.com/documentation/safariservices/running-your-safari-web-extension): Mac 앱을 빌드·실행해 확장을 등록하며, 임시 확장과 unsigned 허용 설정은 Safari 종료 시 유지되지 않습니다.
