# 냥스타저장 Safari 프로젝트 준비

이 패키지는 설치한 Xcode로 Safari 도우미의 **Mac용 프로젝트를 만들고 여는 준비 도구**입니다. 완성된 앱 설치본이 아닙니다. 프로젝트 생성 뒤 서명 설정, 빌드·설치, Safari 재시작 후 유지 확인을 이어서 진행합니다.

[통합 설치 안내](https://ane1235.github.io/instadown/)에서 **Safari**를 선택하고 준비 ZIP을 받습니다. Xcode 프로젝트 준비 도구는 **v3**, 포함된 공통 브라우저 도우미는 **0.3.0**입니다. 웹앱은 공개 HTTPS 주소로 연결하며 별도 네트워크 선택은 없습니다.

1. Mac에서 ZIP을 풀고 `Nyangsta-Safari-App` 폴더를 엽니다.
2. Xcode는 설치 후 한 번 실행해 초기 설정을 마친 상태여야 합니다. Mac의 Terminal에서 아래 명령을 실행합니다.
3. 터미널에 **`프로젝트 생성 완료: … .xcodeproj` 경로가 표시되고 Xcode 왼쪽에 `냥스타저장` 프로젝트가 보이는지** 확인합니다. Open / Clone / New Project만 있는 시작 화면이라면 터미널의 결과부터 확인합니다. 생성에 성공하면 아래 서명·설치 단계로 이어갑니다.
4. 오류가 나오면 Terminal의 오류 문구만 알려주세요. 비밀번호, 인증서, 쿠키나 로그 전체를 보내지 마세요.

```sh
/bin/zsh "$HOME/Downloads/Nyangsta-Safari-App/Prepare-Safari.command"
```

ZIP을 다른 위치에 풀었다면 위 경로를 실제 폴더 경로로 바꾸고 큰따옴표를 유지하세요. 다운로드한 실행 파일이라 macOS가 실행을 막으면 보호 설정을 끄거나 파일 속성을 변경하지 말고, 표시된 문구를 알려주세요. Python을 찾지 못하거나 Xcode가 선택되지 않았다는 오류도 그대로 알려주세요.

생성 결과는 Mac의 `Downloads/Nyangsta-Safari-Project-날짜-시간` 폴더에 보관합니다. 같은 이름의 폴더가 있으면 숫자를 붙여 새 폴더를 사용하며 기존 파일을 덮어쓰지 않습니다. 경로에 공백이나 한글이 있어도 그대로 처리합니다. 표준 `/Applications/Xcode.app`이 있으면 이번 실행에만 사용하고, 없으면 현재 선택된 개발 도구를 사용합니다. 컴퓨터 전체의 개발 도구 설정은 바꾸지 않습니다.

준비 도구 v3는 새 프로젝트의 앱·확장 모듈, 기본 Bundle Identifier, 스토리보드 클래스 참조와 Debug 빌드 설정을 자동으로 맞춥니다. 현재 Mac에서 검증한 설정을 새 프로젝트에도 적용하며, 기존 프로젝트를 수정하지 않습니다. 해당 Debug 구성에서는 Xcode Previews를 사용할 수 없습니다. 초기 도구 확인에서 실패한 명령과 원문도 표시합니다. 도움말 명령만 종료 코드 0/64와 필수 옵션 전체를 함께 확인하며, 다른 실패를 무시하지 않습니다. 폴더가 없는 경우 Xcode에서 새 프로젝트를 만드는 대신 터미널에 표시된 실패 원인부터 확인합니다.

GitHub의 설치 안내 페이지에 게시된 준비 파일을 기존 파일과 섞이지 않게 새 폴더에 받아 실행하려면 Mac 터미널에 다음 전체를 붙여 넣습니다. 각 단계가 성공해야 다음 단계로 넘어가며 기존 파일은 보존합니다.

```sh
nyangsta_setup_dir=$(mktemp -d "$HOME/Downloads/Nyangsta-Safari-v3.XXXXXX") &&
/usr/bin/curl --fail --show-error --location 'https://ane1235.github.io/instadown/browser-helper/Nyangsta-Safari-App.zip' --output "$nyangsta_setup_dir/setup.zip" &&
/usr/bin/ditto -x -k "$nyangsta_setup_dir/setup.zip" "$nyangsta_setup_dir" &&
/bin/zsh "$nyangsta_setup_dir/Nyangsta-Safari-App/Prepare-Safari.command"
```

패키지에는 준비 스크립트와 검증에 사용한 공통 확장 소스만 포함됩니다. 준비 과정은 인터넷에서 도구를 받거나, 계정 로그인·인증서 생성·키체인 조회·서명·Safari 종료·앱 설치를 수행하지 않습니다. 결과를 서버에 자동 전송하지도 않습니다. Xcode에서 열린 프로젝트의 빌드와 서명은 다음 단계입니다.

`browser-extension/SAFARI.md`는 기존 **임시 설치** 안내입니다. 이 준비 도구로 생성하는 Xcode 프로젝트의 설치 안내와 구분하세요. 서명 없이 실행하는 확장은 Safari의 unsigned 허용 설정이 재시작 때 해제되므로 재시작 후 유지 성공으로 볼 수 없습니다. 사용자 Mac에서 실제 서명과 재시작 결과를 확인하기 전까지 지속 설치 완료로 표시하지 않습니다.

## 현재 검증 상태와 다른 Mac 설치

현재 사용 중인 Mac에서는 앱·확장 서명 검사, Safari 종료/재실행 후 도우미 연결, 사진·영상 스토리 저장까지 확인했습니다. 정상 작동하는 기존 프로젝트에서 이 준비 도구를 다시 실행할 필요는 없습니다.

v3는 **다른 Mac에서 새 프로젝트를 만들 때** 앞선 수동 설정 수정을 반복하지 않도록 개선한 소스 패키지입니다. 새 생성 기능의 모의 검사와 패키지 내용 검증은 실제 다른 Mac의 생성·빌드·설치 검증과 구별합니다. 새 Mac에서는 Xcode 프로젝트 생성 후 앱과 Extension의 Signing & Capabilities에서 본인 Team을 지정해 빌드합니다. 내부 모듈이나 Bundle Identifier를 다시 바꿀 필요는 없습니다.

1. Xcode의 Settings → Accounts에 사용할 Apple 계정을 추가하고, 앱과 Extension 두 target의 Signing & Capabilities에서 같은 본인 Team과 자동 서명을 선택합니다.
2. 상단 scheme을 Mac 앱, 실행 대상을 My Mac으로 선택해 Run합니다. 생성기가 정렬한 모듈·Bundle Identifier는 유지합니다. 서명이나 빌드 오류가 있으면 해당 오류부터 해결합니다.
3. 앱이 실행되면 Safari 설정의 확장 프로그램에서 도우미를 켭니다. 프로필을 사용한다면 Instagram에 로그인한 프로필에서도 켜고, Instagram과 선택한 냥스타저장 웹앱 사이트의 접근을 허용합니다.
4. 설치 안내의 연결 확인 페이지를 열어 **도우미 연결됨**을 확인합니다. 이 단계에서는 Instagram을 조회하지 않습니다.

이 ZIP은 **서명·공증 완료 앱이 아니며**, 다른 Mac에 압축만 풀어 설치하는 배포본이 아닙니다. Xcode 없이 설치하는 앱 배포에는 별도 서명·배포 절차가 필요합니다. 새 Mac에서 앱 실행·Safari 사이트 접근 허용·종료/재실행 후 저장까지 확인하세요.

빌드 산출물은 Xcode의 DerivedData 안에 있으므로 개발 캐시를 정리하면 없어질 수 있습니다. 계속 사용할 앱은 빌드/서명 확인 뒤 응용 프로그램 폴더에 복사해 그 복사본을 실행합니다. 같은 이름의 앱이 이미 있으면 합쳐 덮어쓰지 말고 기존 버전을 먼저 확인하세요. 앱 내부 파일이나 서명은 편집하지 않습니다.

## 웹앱 연결과 완료 확인

[통합 설치 안내](https://ane1235.github.io/instadown/)의 **냥스타저장 열기**를 눌러 [공개 웹앱](https://kayenpc.tail730e13.ts.net:10000/)으로 이동합니다. 설치할 Mac에 Tailscale을 설치하거나 네트워크 방식을 선택할 필요가 없습니다. 확장에 서버 주소를 따로 입력하지 않습니다.

응용 프로그램 폴더 복사본으로 실행한 뒤 Safari를 완전히 종료하고 다시 열어 연결이 유지되는지 확인합니다. 이어 같은 Safari 프로필의 Instagram에서 열리는 개별 스토리를 저장하고 내려받은 사진·영상을 확인합니다. 공통 도우미 0.3.0의 모의 검사만으로 실제 Mac 설치·연결·저장 성공을 보장하지 않습니다.

## 공식 근거

2026-09-19 Apple 패키징·실행·권한 본문 재확인. 개별 문서의 갱신일은 표시되지 않았습니다.

- [Safari 확장 패키지 만들기](https://developer.apple.com/documentation/safariservices/packaging-a-web-extension-for-safari): Xcode의 packager가 Mac 앱과 확장 프로젝트를 생성합니다. 기존 converter 이름도 지원합니다.
- [Safari 확장 실행](https://developer.apple.com/documentation/safariservices/running-your-safari-web-extension): Mac 앱을 빌드·실행해 확장을 등록하며, 임시 확장과 unsigned 허용 설정은 Safari 종료 시 유지되지 않습니다.
- [Safari 웹 확장 권한](https://developer.apple.com/documentation/safariservices/managing-safari-web-extension-permissions): Instagram과 사용하는 웹앱 사이트의 접근 허용.

- [Xcode 빌드 산출물 구조](https://developer.apple.com/documentation/xcode/understanding-build-product-layout-changes): target별 ENABLE_DEBUG_DYLIB=NO와 해당 target의 Previews 영향.
- [Safari 확장 배포](https://developer.apple.com/documentation/safariservices/distributing-your-safari-web-extension): App Store 외 배포의 Developer ID 서명과 공증.
