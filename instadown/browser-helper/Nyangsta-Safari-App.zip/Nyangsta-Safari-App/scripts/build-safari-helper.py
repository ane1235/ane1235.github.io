#!/usr/bin/env python3
"""Build the Safari test package from the shared, reviewed extension runtime."""
import argparse
import hashlib
import io
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


ROOT = Path(__file__).resolve().parent.parent
RUNTIME_FILES = (
    'protocol.js', 'web-bridge.js', 'service-worker.js', 'instagram-collector.js',
)


def build_package(source: Path, destination: Path) -> Path:
    """Only adapt browser metadata; keep every runtime file byte-for-byte."""
    manifest = json.loads((source / 'manifest.json').read_text(encoding='utf-8'))
    manifest.pop('minimum_chrome_version', None)
    manifest['name'] = '냥스타저장 Safari 도우미'
    manifest['description'] = '같은 Safari 프로필의 Instagram 로그인으로 요청한 개별 스토리를 냥스타저장에 연결합니다.'
    manifest['browser_specific_settings'] = {'safari': {'strict_min_version': '16.4'}}
    payloads = {
        'manifest.json': (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8'),
        **{name: (source / name).read_bytes() for name in RUNTIME_FILES},
        'README.md': (source / 'SAFARI.md').read_bytes(),
    }
    buffer = io.BytesIO()
    with ZipFile(buffer, 'w', compression=ZIP_DEFLATED) as archive:
        for name, payload in payloads.items():
            entry = ZipInfo('Nyangsta-Safari/' + name, date_time=(2026, 9, 18, 0, 0, 0))
            entry.create_system = 3
            entry.compress_type = ZIP_DEFLATED
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, payload)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(buffer.getvalue())
    return destination


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT / 'ig_downloader/web/Nyangsta-Safari.zip')
    args = parser.parse_args()
    destination = build_package(ROOT / 'browser-extension', args.output)
    print(destination)
    print('SHA256', hashlib.sha256(destination.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
