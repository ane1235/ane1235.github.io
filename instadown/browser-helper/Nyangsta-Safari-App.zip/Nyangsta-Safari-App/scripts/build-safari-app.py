#!/usr/bin/env python3
"""Safari macOS Xcode 프로젝트 생성; 선택적으로 기존 개발 인증서로 빌드합니다."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import tempfile
from zipfile import BadZipFile, ZipFile


ROOT = Path(__file__).resolve().parent.parent
APP_NAME = '냥스타저장'
BUNDLE_ID = 'io.github.ane1235.nyangstasave'
PACKAGER_OPTIONS = (
    '--project-location', '--app-name', '--bundle-identifier', '--swift',
    '--macos-only', '--copy-resources', '--no-open', '--no-prompt',
)
# Only these fixed, read-only invocations may include captured output in errors.
# Build/signing commands may contain user-selected paths or signing information.
SAFE_PREFLIGHT_COMMANDS = {
    ('xcode-select', '-p'), ('xcodebuild', '-version'),
    ('safari-web-extension-packager', '--help'),
    ('safari-web-extension-converter', '--help'),
}
DIAGNOSTIC_OUTPUT_LIMIT = 2000


class BuildError(Exception):
    """An actionable local preparation/build failure."""


def command_diagnostic(argv, result=None):
    command = (Path(argv[0]).name, *(str(value) for value in argv[1:]))
    safe_preflight = command in SAFE_PREFLIGHT_COMMANDS
    label = ' '.join(command) if safe_preflight else command[0]
    detail = ' 도구: ' + label
    if safe_preflight and result is not None:
        for name, value in (('stderr', result.stderr), ('stdout', result.stdout)):
            if value and value.strip():
                # Keep multiline diagnostics readable without terminal control codes.
                clean = ''.join(char for char in value.strip() if char.isprintable() or char in '\n\t')
                excerpt = clean[:DIAGNOSTIC_OUTPUT_LIMIT]
                if len(clean) > DIAGNOSTIC_OUTPUT_LIMIT:
                    excerpt += '\n[이후 출력 생략]'
                detail += '\n' + name + ':\n' + excerpt
    return detail


def command_failure(argv, result, log=None):
    detail = command_diagnostic(argv, result if log is None else None)
    if log is not None:
        detail += ' 기록: ' + str(log)
    return BuildError('개발 도구 실행 실패(exit %s).%s' % (result.returncode, detail))


def run(argv, *, timeout=30, log=None, check=True):
    """Never use a shell, interactive stdin, or provisioning/authentication flags."""
    try:
        result = subprocess.run(
            [str(value) for value in argv], stdin=subprocess.DEVNULL,
            capture_output=True, text=True, timeout=timeout, check=False, shell=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise BuildError('개발 도구를 실행할 수 없거나 제한 시간을 초과했습니다.' + command_diagnostic(argv)) from exc
    if log is not None:
        log.write_text(result.stdout + '\n' + result.stderr, encoding='utf-8')
    if check and result.returncode:
        raise command_failure(argv, result, log)
    return result


def discover_tools(build):
    if platform.system() != 'Darwin':
        raise BuildError('이 단계는 full Xcode가 설치된 macOS에서 실행해야 합니다. --help는 모든 OS에서 사용할 수 있습니다.')
    xcrun = shutil.which('xcrun')
    if not xcrun:
        raise BuildError('xcrun이 없습니다. full Xcode를 설치하고 한 번 실행해 초기 설정을 마치세요.')
    selected = os.environ.get('DEVELOPER_DIR')
    if not selected:
        selector = shutil.which('xcode-select')
        if not selector:
            raise BuildError('xcode-select가 없습니다. full Xcode 설치를 확인하세요.')
        selected = run([selector, '-p']).stdout.strip()
    developer = Path(selected).expanduser()
    if developer.suffix == '.app':
        developer /= 'Contents/Developer'
    xcodebuild = developer / 'usr/bin/xcodebuild'
    if not xcodebuild.is_file():
        raise BuildError('full Xcode가 선택되지 않았습니다. Command Line Tools만으로는 만들 수 없습니다. '
                         'Xcode의 Settings → Locations에서 Command Line Tools를 선택하거나 DEVELOPER_DIR를 지정하세요.')
    version = run([xcodebuild, '-version']).stdout.strip()
    packager = None
    for name in ('safari-web-extension-packager', 'safari-web-extension-converter'):
        found = run([xcrun, '--find', name], check=False)
        if found.returncode == 0 and found.stdout.strip():
            packager = Path(found.stdout.strip())
            break
    if packager is None:
        raise BuildError('선택된 Xcode에 Safari packager/converter가 없습니다. full Xcode 설치를 확인하세요.')
    help_command = [packager, '--help']
    help_result = run(help_command, check=False)
    # Some tools use EX_USAGE (64) when printing help. Accept that only for this
    # help probe, and only after confirming every option needed for generation.
    if help_result.returncode not in (0, 64):
        raise command_failure(help_command, help_result)
    help_text = help_result.stdout + '\n' + help_result.stderr
    missing = [option for option in PACKAGER_OPTIONS
               if not re.search(r'(?<![\w-])' + re.escape(option) + r'(?![\w-])', help_text)]
    if missing:
        raise BuildError('설치된 Safari 도구의 도움말에서 필요한 옵션을 확인하지 못했습니다 '
                         '(exit %s): %s.%s' % (help_result.returncode, ', '.join(missing),
                                             command_diagnostic(help_command, help_result)))
    codesign = shutil.which('codesign') if build else None
    if build and not codesign:
        raise BuildError('codesign을 찾을 수 없어 서명 빌드를 검증할 수 없습니다.')
    return packager, xcodebuild, codesign, version


def read_package(package):
    """Reuse the Safari ZIP builder and only unpack its fixed six-file boundary."""
    spec = importlib.util.spec_from_file_location('nyangsta_safari_package', ROOT / 'scripts/build-safari-helper.py')
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
    with tempfile.TemporaryDirectory(prefix='nyangsta-safari-package-') as temporary:
        if package is None:
            package = builder.build_package(ROOT / 'browser-extension', Path(temporary) / 'Nyangsta-Safari.zip')
        if not package.is_file() or package.stat().st_size > 2 * 1024 * 1024:
            raise BuildError('Safari ZIP 파일이 없거나 크기 제한(2 MiB)을 넘었습니다.')
        archive_bytes = package.read_bytes()
        expected = {'Nyangsta-Safari/' + name for name in ('manifest.json', *builder.RUNTIME_FILES, 'README.md')}
        try:
            with ZipFile(io.BytesIO(archive_bytes)) as archive:
                entries = archive.infolist()
                if len(entries) != len(expected) or {entry.filename for entry in entries} != expected:
                    raise BuildError('Safari ZIP의 파일 목록이 준비된 도우미와 다릅니다. build-safari-helper.py로 다시 만드세요.')
                if any(entry.file_size > 1024 * 1024 or entry.is_dir() or
                       (entry.external_attr >> 16) & 0o170000 == 0o120000 for entry in entries):
                    raise BuildError('Safari ZIP에 허용하지 않는 파일이 있습니다.')
                payloads = {Path(entry.filename).name: archive.read(entry) for entry in entries}
                manifest = json.loads(payloads['manifest.json'])
                if not isinstance(manifest, dict) or manifest.get('manifest_version') != 3:
                    raise BuildError('Safari ZIP의 manifest가 올바르지 않습니다.')
        except (BadZipFile, ValueError, RuntimeError) as exc:
            raise BuildError('Safari ZIP을 읽을 수 없습니다. 새 패키지로 다시 시도하세요.') from exc
    return archive_bytes, payloads


def select_scheme(xcodebuild, project, requested, output):
    response = run([xcodebuild, '-list', '-json', '-project', project], log=output / 'schemes.log')
    try:
        schemes = json.loads(response.stdout)['project']['schemes']
        if not isinstance(schemes, list) or not all(isinstance(name, str) for name in schemes):
            raise ValueError('invalid schemes')
    except (ValueError, KeyError, TypeError) as exc:
        raise BuildError('생성된 Xcode scheme 목록을 읽지 못했습니다. schemes.log를 확인하세요.') from exc
    if requested:
        if requested not in schemes:
            raise BuildError('요청한 scheme이 없습니다. 생성된 프로젝트의 scheme을 확인하세요.')
        return requested
    for candidate in (APP_NAME, APP_NAME + ' (macOS)'):
        if candidate in schemes:
            return candidate
    if len(schemes) == 1:
        return schemes[0]
    raise BuildError('macOS 앱 scheme을 하나로 결정하지 못했습니다. --scheme으로 지정하세요.')


def signed_build(xcodebuild, codesign, project, output, team, requested_scheme):
    scheme = select_scheme(xcodebuild, project, requested_scheme, output)
    derived = output / 'DerivedData'
    run([
        xcodebuild, '-project', project, '-scheme', scheme, '-configuration', 'Release',
        '-sdk', 'macosx', '-destination', 'platform=macOS', '-derivedDataPath', derived,
        'build', 'CODE_SIGN_STYLE=Manual', 'DEVELOPMENT_TEAM=' + team,
        'CODE_SIGN_IDENTITY=Apple Development', 'CODE_SIGNING_ALLOWED=YES', 'CODE_SIGNING_REQUIRED=YES',
    ], timeout=900, log=output / 'build.log')
    apps = sorted((derived / 'Build/Products/Release').glob('*.app'))
    if len(apps) != 1:
        raise BuildError('빌드 결과에서 macOS 앱을 하나로 확인하지 못했습니다. build.log를 확인하세요.')
    app = apps[0]
    extensions = list((app / 'Contents/PlugIns').glob('*.appex'))
    if len(extensions) != 1:
        raise BuildError('빌드한 앱에 Safari 확장이 정확히 한 개 포함되지 않았습니다.')
    for bundle in [app, *extensions]:
        run([codesign, '--verify', '--deep', '--strict', bundle])
        signature = run([codesign, '-dv', '--verbose=4', bundle])
        lines = (signature.stdout + '\n' + signature.stderr).splitlines()
        if not any(line.startswith('Authority=Apple Development:') for line in lines) or 'TeamIdentifier=' + team not in lines:
            raise BuildError('앱/확장의 서명이 요청한 팀의 Apple Development 인증서와 일치하지 않습니다.')
    return app, scheme


def prepare(output, *, package=None, build=False, team=None, scheme=None):
    # Even an empty directory or symlink is preserved. Use a fresh explicit path.
    output = output.expanduser().absolute()
    if output.exists() or output.is_symlink():
        raise BuildError('출력 경로가 이미 있습니다. 기존 프로젝트를 보존하므로 새 --output 경로를 지정하세요.')
    if build:
        team = team or os.environ.get('DEVELOPMENT_TEAM')
        if not team or not re.fullmatch(r'[A-Z0-9]{10}', team):
            raise BuildError('--build에는 기존 인증서의 10자리 팀 ID(--team 또는 DEVELOPMENT_TEAM)가 필요합니다.')
    elif team or scheme:
        raise BuildError('--team과 --scheme은 --build와 함께 지정하세요.')
    packager, xcodebuild, codesign, version = discover_tools(build)
    archive_bytes, payloads = read_package(package.expanduser() if package else None)
    output.mkdir(parents=True, exist_ok=False)
    (output / 'Nyangsta-Safari.zip').write_bytes(archive_bytes)
    extension = output / 'Extension'
    extension.mkdir()
    for name, payload in payloads.items():
        (extension / name).write_bytes(payload)
    (output / 'Project').mkdir()
    run([
        packager, extension, '--project-location', output / 'Project', '--app-name', APP_NAME,
        '--bundle-identifier', BUNDLE_ID, '--swift', '--macos-only', '--copy-resources', '--no-open', '--no-prompt',
    ], timeout=120, log=output / 'packager.log')
    projects = list((output / 'Project').rglob('*.xcodeproj'))
    if len(projects) != 1 or not (projects[0] / 'project.pbxproj').is_file():
        raise BuildError('생성된 Xcode 프로젝트를 하나로 확인하지 못했습니다. packager.log를 확인하세요.')
    project = projects[0]
    record = {
        'version': 1, 'state': 'project_generated', 'bundle_identifier': BUNDLE_ID,
        'package_sha256': hashlib.sha256(archive_bytes).hexdigest(),
        'packager': packager.name, 'xcode_version': version,
        'project': str(project.relative_to(output)),
        'installation_verified': False, 'safari_restart_verified': False,
    }
    (output / 'build-record.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    if build:
        app, used_scheme = signed_build(xcodebuild, codesign, project, output, team, scheme)
        record.update(state='signed_build_verified', app=str(app.relative_to(output)), scheme=used_scheme)
        (output / 'build-record.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return record


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, epilog='앱 자동 설치·실행, 계정 로그인, 인증서 생성, 자동 프로비저닝은 하지 않습니다.')
    parser.add_argument('--output', required=True, type=Path, help='새 출력 폴더. 기존 폴더는 덮어쓰지 않습니다.')
    parser.add_argument('--package', type=Path, help='기존 Nyangsta-Safari.zip. 생략하면 공통 소스에서 새 ZIP을 생성합니다.')
    parser.add_argument('--build', action='store_true', help='기존 Apple Development 인증서로 수동 서명 빌드도 수행합니다.')
    parser.add_argument('--team', help='사용자가 지정한 기존 인증서의 팀 ID; 생략 시 DEVELOPMENT_TEAM 환경 변수.')
    parser.add_argument('--scheme', help='앱 scheme을 자동 선택할 수 없을 때 명시합니다.')
    args = parser.parse_args(argv)
    try:
        result = prepare(args.output, package=args.package, build=args.build, team=args.team, scheme=args.scheme)
    except (BuildError, OSError) as exc:
        print('오류: ' + str(exc), file=sys.stderr)
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    print('프로젝트/빌드 준비 결과입니다. Safari 설치·재시작 유지·실제 저장은 별도로 확인해야 합니다.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
