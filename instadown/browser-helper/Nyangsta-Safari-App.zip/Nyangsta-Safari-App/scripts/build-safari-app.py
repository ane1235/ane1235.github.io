#!/usr/bin/env python3
"""Safari macOS Xcode 프로젝트 생성; 선택적으로 기존 개발 인증서로 빌드합니다."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import platform
import plistlib
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import unicodedata
import xml.etree.ElementTree as ET
from xml.parsers.expat import ExpatError
from zipfile import BadZipFile, ZipFile


ROOT = Path(__file__).resolve().parent.parent
APP_NAME = '냥스타저장'
BUNDLE_ID = 'io.github.ane1235.nyangstasave'
PACKAGER_OPTIONS = (
    '--project-location', '--app-name', '--bundle-identifier', '--swift',
    '--macos-only', '--copy-resources', '--no-open', '--no-prompt',
)
# Only these fixed, read-only invocations may include captured output in errors.
# Build/signing commands may contain user-selected paths or signing information.
SAFE_PREFLIGHT_COMMANDS = {
    ('xcode-select', '-p'), ('xcodebuild', '-version'),
    ('safari-web-extension-packager', '--help'),
    ('safari-web-extension-converter', '--help'),
}
DIAGNOSTIC_OUTPUT_LIMIT = 2000


class BuildError(Exception):
    """An actionable local preparation/build failure."""


def command_diagnostic(argv, result=None):
    command = (Path(argv[0]).name, *(str(value) for value in argv[1:]))
    safe_preflight = command in SAFE_PREFLIGHT_COMMANDS
    label = ' '.join(command) if safe_preflight else command[0]
    detail = ' 도구: ' + label
    if safe_preflight and result is not None:
        for name, value in (('stderr', result.stderr), ('stdout', result.stdout)):
            if value and value.strip():
                # Keep multiline diagnostics readable without terminal control codes.
                clean = ''.join(char for char in value.strip() if char.isprintable() or char in '\n\t')
                excerpt = clean[:DIAGNOSTIC_OUTPUT_LIMIT]
                if len(clean) > DIAGNOSTIC_OUTPUT_LIMIT:
                    excerpt += '\n[이후 출력 생략]'
                detail += '\n' + name + ':\n' + excerpt
    return detail


def command_failure(argv, result, log=None):
    detail = command_diagnostic(argv, result if log is None else None)
    if log is not None:
        detail += ' 기록: ' + str(log)
    return BuildError('개발 도구 실행 실패(exit %s).%s' % (result.returncode, detail))


def run(argv, *, timeout=30, log=None, check=True):
    """Never use a shell, interactive stdin, or provisioning/authentication flags."""
    try:
        result = subprocess.run(
            [str(value) for value in argv], stdin=subprocess.DEVNULL,
            capture_output=True, text=True, timeout=timeout, check=False, shell=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise BuildError('개발 도구를 실행할 수 없거나 제한 시간을 초과했습니다.' + command_diagnostic(argv)) from exc
    if log is not None:
        log.write_text(result.stdout + '\n' + result.stderr, encoding='utf-8')
    if check and result.returncode:
        raise command_failure(argv, result, log)
    return result


def discover_tools(build):
    if platform.system() != 'Darwin':
        raise BuildError('이 단계는 full Xcode가 설치된 macOS에서 실행해야 합니다. --help는 모든 OS에서 사용할 수 있습니다.')
    xcrun = shutil.which('xcrun')
    if not xcrun:
        raise BuildError('xcrun이 없습니다. full Xcode를 설치하고 한 번 실행해 초기 설정을 마치세요.')
    selected = os.environ.get('DEVELOPER_DIR')
    if not selected:
        selector = shutil.which('xcode-select')
        if not selector:
            raise BuildError('xcode-select가 없습니다. full Xcode 설치를 확인하세요.')
        selected = run([selector, '-p']).stdout.strip()
    developer = Path(selected).expanduser()
    if developer.suffix == '.app':
        developer /= 'Contents/Developer'
    xcodebuild = developer / 'usr/bin/xcodebuild'
    if not xcodebuild.is_file():
        raise BuildError('full Xcode가 선택되지 않았습니다. Command Line Tools만으로는 만들 수 없습니다. '
                         'Xcode의 Settings → Locations에서 Command Line Tools를 선택하거나 DEVELOPER_DIR를 지정하세요.')
    version = run([xcodebuild, '-version']).stdout.strip()
    packager = None
    for name in ('safari-web-extension-packager', 'safari-web-extension-converter'):
        found = run([xcrun, '--find', name], check=False)
        if found.returncode == 0 and found.stdout.strip():
            packager = Path(found.stdout.strip())
            break
    if packager is None:
        raise BuildError('선택된 Xcode에 Safari packager/converter가 없습니다. full Xcode 설치를 확인하세요.')
    help_command = [packager, '--help']
    help_result = run(help_command, check=False)
    # Some tools use EX_USAGE (64) when printing help. Accept that only for this
    # help probe, and only after confirming every option needed for generation.
    if help_result.returncode not in (0, 64):
        raise command_failure(help_command, help_result)
    help_text = help_result.stdout + '\n' + help_result.stderr
    missing = [option for option in PACKAGER_OPTIONS
               if not re.search(r'(?<![\w-])' + re.escape(option) + r'(?![\w-])', help_text)]
    if missing:
        raise BuildError('설치된 Safari 도구의 도움말에서 필요한 옵션을 확인하지 못했습니다 '
                         '(exit %s): %s.%s' % (help_result.returncode, ', '.join(missing),
                                             command_diagnostic(help_command, help_result)))
    codesign = shutil.which('codesign') if build else None
    if build and not codesign:
        raise BuildError('codesign을 찾을 수 없어 서명 빌드를 검증할 수 없습니다.')
    return packager, xcodebuild, codesign, version


def read_package(package):
    """Reuse the Safari ZIP builder and only unpack its fixed six-file boundary."""
    spec = importlib.util.spec_from_file_location('nyangsta_safari_package', ROOT / 'scripts/build-safari-helper.py')
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
    with tempfile.TemporaryDirectory(prefix='nyangsta-safari-package-') as temporary:
        if package is None:
            package = builder.build_package(ROOT / 'browser-extension', Path(temporary) / 'Nyangsta-Safari.zip')
        if not package.is_file() or package.stat().st_size > 2 * 1024 * 1024:
            raise BuildError('Safari ZIP 파일이 없거나 크기 제한(2 MiB)을 넘었습니다.')
        archive_bytes = package.read_bytes()
        expected = {'Nyangsta-Safari/' + name for name in ('manifest.json', *builder.RUNTIME_FILES, 'README.md')}
        try:
            with ZipFile(io.BytesIO(archive_bytes)) as archive:
                entries = archive.infolist()
                if len(entries) != len(expected) or {entry.filename for entry in entries} != expected:
                    raise BuildError('Safari ZIP의 파일 목록이 준비된 도우미와 다릅니다. build-safari-helper.py로 다시 만드세요.')
                if any(entry.file_size > 1024 * 1024 or entry.is_dir() or
                       (entry.external_attr >> 16) & 0o170000 == 0o120000 for entry in entries):
                    raise BuildError('Safari ZIP에 허용하지 않는 파일이 있습니다.')
                payloads = {Path(entry.filename).name: archive.read(entry) for entry in entries}
                manifest = json.loads(payloads['manifest.json'])
                if not isinstance(manifest, dict) or manifest.get('manifest_version') != 3:
                    raise BuildError('Safari ZIP의 manifest가 올바르지 않습니다.')
        except (BadZipFile, ValueError, RuntimeError) as exc:
            raise BuildError('Safari ZIP을 읽을 수 없습니다. 새 패키지로 다시 시도하세요.') from exc
    return archive_bytes, payloads


def select_scheme(xcodebuild, project, requested, output):
    response = run([xcodebuild, '-list', '-json', '-project', project], log=output / 'schemes.log')
    try:
        schemes = json.loads(response.stdout)['project']['schemes']
        if not isinstance(schemes, list) or not all(isinstance(name, str) for name in schemes):
            raise ValueError('invalid schemes')
    except (ValueError, KeyError, TypeError) as exc:
        raise BuildError('생성된 Xcode scheme 목록을 읽지 못했습니다. schemes.log를 확인하세요.') from exc
    if requested:
        if requested not in schemes:
            raise BuildError('요청한 scheme이 없습니다. 생성된 프로젝트의 scheme을 확인하세요.')
        return requested
    for candidate in (APP_NAME, APP_NAME + ' (macOS)'):
        if candidate in schemes:
            return candidate
    if len(schemes) == 1:
        return schemes[0]
    raise BuildError('macOS 앱 scheme을 하나로 결정하지 못했습니다. --scheme으로 지정하세요.')


def signed_build(xcodebuild, codesign, project, output, team, requested_scheme):
    scheme = select_scheme(xcodebuild, project, requested_scheme, output)
    derived = output / 'DerivedData'
    run([
        xcodebuild, '-project', project, '-scheme', scheme, '-configuration', 'Release',
        '-sdk', 'macosx', '-destination', 'platform=macOS', '-derivedDataPath', derived,
        'build', 'CODE_SIGN_STYLE=Manual', 'DEVELOPMENT_TEAM=' + team,
        'CODE_SIGN_IDENTITY=Apple Development', 'CODE_SIGNING_ALLOWED=YES', 'CODE_SIGNING_REQUIRED=YES',
    ], timeout=900, log=output / 'build.log')
    apps = sorted((derived / 'Build/Products/Release').glob('*.app'))
    if len(apps) != 1:
        raise BuildError('빌드 결과에서 macOS 앱을 하나로 확인하지 못했습니다. build.log를 확인하세요.')
    app = apps[0]
    extensions = list((app / 'Contents/PlugIns').glob('*.appex'))
    if len(extensions) != 1:
        raise BuildError('빌드한 앱에 Safari 확장이 정확히 한 개 포함되지 않았습니다.')
    for bundle in [app, *extensions]:
        run([codesign, '--verify', '--deep', '--strict', bundle])
        signature = run([codesign, '-dv', '--verbose=4', bundle])
        lines = (signature.stdout + '\n' + signature.stderr).splitlines()
        if not any(line.startswith('Authority=Apple Development:') for line in lines) or 'TeamIdentifier=' + team not in lines:
            raise BuildError('앱/확장의 서명이 요청한 팀의 Apple Development 인증서와 일치하지 않습니다.')
    return app, scheme


def project_spans(text):
    """Locate OpenStep values without reserializing comments or unrelated settings."""
    tokens = []
    lexer = re.compile(r'\s+|/\*[\s\S]*?\*/|//[^\r\n]*|"(?:[^"\\]|\\[\s\S])*"|[{}()=;,]|[^\s{}()=;,"]+')
    position = 0
    while position < len(text):
        match = lexer.match(text, position)
        if match is None:
            raise BuildError('프로젝트 원문의 구문을 안전하게 확인하지 못했습니다.')
        raw = match.group()
        if not (raw.isspace() or raw.startswith(('/*', '//'))):
            tokens.append((raw, match.start(), match.end()))
        position = match.end()
    position = 0

    def take(expected=None):
        nonlocal position
        if position >= len(tokens) or (expected is not None and tokens[position][0] != expected):
            raise BuildError('프로젝트 원문의 항목 경계를 확인하지 못했습니다.')
        token = tokens[position]
        position += 1
        return token

    def value(depth=0):
        if depth > 64:
            raise BuildError('프로젝트 원문의 중첩 범위가 예상보다 큽니다.')
        first = take()
        node = {'start': first[1], 'end': first[2], 'kind': first[0], 'entries': {}}
        if first[0] == '{':
            while position < len(tokens) and tokens[position][0] != '}':
                key = take()[0]
                if key.startswith('"'):
                    key = key[1:-1]
                if '\\' in key or key in '{}()=;,' or key in node['entries']:
                    raise BuildError('중복되거나 예상하지 않은 프로젝트 키가 있습니다.')
                take('=')
                node['entries'][key] = value(depth + 1)
                take(';')
            last = take('}')
            node.update(end=last[2], close=last[1])
        elif first[0] == '(':
            while position < len(tokens) and tokens[position][0] != ')':
                value(depth + 1)
                if position < len(tokens) and tokens[position][0] == ',':
                    take(',')
                elif position < len(tokens) and tokens[position][0] != ')':
                    raise BuildError('프로젝트 배열 구문을 확인하지 못했습니다.')
            node['end'] = take(')')[2]
        elif first[0] in '}=;,':
            raise BuildError('프로젝트 값 구문을 확인하지 못했습니다.')
        return node

    root = value()
    if root['kind'] != '{' or position != len(tokens):
        raise BuildError('프로젝트 전체 원문 구조를 확인하지 못했습니다.')
    return root



def generated_path(path, boundary, *, directory=False):
    path = Path(path).absolute()
    if (not path.is_relative_to(boundary) or any(item.is_symlink() for item in (path, *path.parents))
            or not (path.is_dir() if directory else path.is_file())):
        raise BuildError('새 생성 폴더 안의 일반 파일·폴더 경계를 확인하지 못했습니다.')
    if not directory and path.stat().st_size > 16 * 1024 * 1024:
        raise BuildError('생성 파일의 크기 제한을 넘었습니다.')
    return path


def generated_project_data(path):
    result = run(['/usr/bin/plutil', '-convert', 'json', '-o', '-', path])
    try:
        data = json.loads(result.stdout)
        if not isinstance(data, dict) or not isinstance(data.get('objects'), dict):
            raise ValueError()
        return data
    except (ValueError, TypeError) as exc:
        raise BuildError('생성된 프로젝트의 설정 구조를 해석하지 못했습니다.') from exc


def normalize_generated_project(output, project):
    """Normalize only the fresh converter output, before recording or building it."""
    boundary = generated_path(output / 'Project', output, directory=True)
    project = generated_path(project, boundary, directory=True)
    files = {}
    for folder, directories, names in os.walk(boundary, followlinks=False):
        if any((Path(folder) / name).is_symlink() for name in directories + names):
            raise BuildError('생성 프로젝트에 심볼릭 링크가 있어 정규화를 중단합니다.')
        for name in names:
            if name in ('Main.storyboard', 'AppDelegate.swift', 'ViewController.swift', 'SafariWebExtensionHandler.swift'):
                files.setdefault(name, []).append(Path(folder) / name)
    if any(len(files.get(name, [])) != 1 for name in
           ('Main.storyboard', 'AppDelegate.swift', 'ViewController.swift', 'SafariWebExtensionHandler.swift')):
        raise BuildError('생성된 화면·앱·확장 소스를 각각 하나로 확인하지 못했습니다.')
    dependencies = {}

    def read(path):
        path = generated_path(path, boundary)
        info = path.stat()
        content = path.read_bytes()
        dependencies[path] = ((info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns), content)
        return content

    pbx = project / 'project.pbxproj'
    original = read(pbx)
    data = generated_project_data(pbx)
    objects = data['objects']
    owner = objects.get(data.get('rootObject'), {})
    targets = [(key, value) for key, value in objects.items() if value.get('isa') == 'PBXNativeTarget']
    kinds = {'com.apple.product-type.application': ('NyangstaSave', BUNDLE_ID, ('AppDelegate.swift', 'ViewController.swift')),
             'com.apple.product-type.app-extension': ('NyangstaSaveExtension', BUNDLE_ID + '.Extension', ('SafariWebExtensionHandler.swift',))}
    if (owner.get('isa') != 'PBXProject' or len(targets) != 2
            or {target.get('productType') for _, target in targets} != set(kinds)
            or sorted(owner.get('targets', [])) != sorted(key for key, _ in targets)):
        raise BuildError('생성된 앱과 Safari 확장 타깃을 정확하게 확인하지 못했습니다.')

    def configurations(target):
        list_id = target.get('buildConfigurationList')
        configuration_list = objects.get(list_id, {})
        ids = configuration_list.get('buildConfigurations', [])
        if (configuration_list.get('isa') != 'XCConfigurationList' or len(ids) != 2 or len(set(ids)) != 2
                or sum(obj.get('buildConfigurationList') == list_id for obj in objects.values()) != 1
                or any(key != list_id and obj.get('isa') == 'XCConfigurationList'
                       and set(ids).intersection(obj.get('buildConfigurations', [])) for key, obj in objects.items())):
            raise BuildError('생성 프로젝트의 전용 Debug·Release 구성을 확인하지 못했습니다.')
        values = [(key, objects.get(key, {})) for key in ids]
        if {value.get('name') for _, value in values} != {'Debug', 'Release'}:
            raise BuildError('생성 프로젝트의 구성 이름이 예상과 다릅니다.')
        for _, value in values:
            settings = value.get('buildSettings')
            if (value.get('isa') != 'XCBuildConfiguration' or not isinstance(settings, dict)
                    or value.get('baseConfigurationReference')
                    or settings.get('INFOPLIST_EXPAND_BUILD_SETTINGS', 'YES') != 'YES'
                    or settings.get('INFOPLIST_PREPROCESS', 'NO') != 'NO'
                    or any(key.startswith(('PRODUCT_MODULE_NAME[', 'PRODUCT_BUNDLE_IDENTIFIER[', 'ENABLE_DEBUG_DYLIB[',
                                           'INFOPLIST_FILE[', 'INFOPLIST_KEY_NSExtension', 'INFOPLIST_KEY_CFBundleIdentifier',
                                           'INFOPLIST_EXPAND_BUILD_SETTINGS[', 'INFOPLIST_PREPROCESS[',
                                           'INFOPLIST_PREFIX_HEADER', 'INFOPLIST_OTHER_PREPROCESSOR_FLAGS')) for key in settings)):
                raise BuildError('생성 프로젝트에 외부·조건부 설정이 있어 자동 변경하지 않습니다.')
        return values

    configurations(owner)
    parents = {}
    for key, node in objects.items():
        if node.get('isa') == 'PBXGroup':
            for child in node.get('children', []):
                parents.setdefault(child, []).append(key)

    def source_path(ref, seen=()):
        if ref in seen or len(seen) > 32:
            raise BuildError('소스 그룹 참조가 순환하거나 너무 깊습니다.')
        node = objects.get(ref, {})
        if node.get('isa') not in ('PBXGroup', 'PBXFileReference'):
            raise BuildError('소스 파일 참조 종류가 예상과 다릅니다.')
        tree = node.get('sourceTree', '<group>')
        relative = node.get('path', '')
        if not isinstance(relative, str) or '$' in relative or '..' in Path(relative).parts or Path(relative).is_absolute():
            raise BuildError('소스 파일 참조가 생성 폴더 밖을 가리킵니다.')
        if tree == 'SOURCE_ROOT' or ref == owner.get('mainGroup'):
            base = project.parent
        elif tree == '<group>' and len(parents.get(ref, [])) == 1:
            base = source_path(parents[ref][0], (*seen, ref))
        else:
            raise BuildError('소스 파일의 그룹 경로를 하나로 확인하지 못했습니다.')
        return base / relative

    changes = {}
    for _, target in targets:
        module, bundle_id, source_names = kinds[target['productType']]
        configs = configurations(target)
        identifiers = {value['buildSettings'].get('PRODUCT_BUNDLE_IDENTIFIER') for _, value in configs}
        if (len(identifiers) != 1 or not all(isinstance(value, str) and
                re.fullmatch(r'io\.github\.ane1235\.[A-Za-z0-9_.-]+', value) for value in identifiers)):
            raise BuildError('생성된 Bundle Identifier의 기본 범위를 확인하지 못했습니다.')
        if target.get('fileSystemSynchronizedGroups'):
            raise BuildError('자동 동기화 소스 그룹은 별도 확인이 필요합니다.')
        membership = []
        for phase_id in target.get('buildPhases', []):
            phase = objects.get(phase_id, {})
            if phase.get('isa') == 'PBXSourcesBuildPhase':
                for entry_id in phase.get('files', []):
                    entry = objects.get(entry_id, {})
                    source = objects.get(entry.get('fileRef'), {})
                    name = Path(source.get('path', source.get('name', ''))).name
                    if name in source_names:
                        reference = generated_path(source_path(entry.get('fileRef')), boundary)
                        if not reference.samefile(files[name][0]):
                            raise BuildError('Compile Sources가 확인한 생성 파일과 다릅니다.')
                        if entry.get('platformFilter') or entry.get('platformFilters'):
                            raise BuildError('생성 소스에 플랫폼별 멤버십이 있어 중단합니다.')
                        membership.append(name)
        if sorted(membership) != sorted(source_names):
            raise BuildError('생성된 앱·확장 Compile Sources가 예상과 다릅니다.')
        for name in source_names:
            source = read(files[name][0]).decode('utf-8')
            if (len(re.findall(r'\bclass\s+' + Path(name).stem + r'\s*:', source)) != 1
                    or re.search(r'@objc\s*\(', source)):
                raise BuildError('생성된 클래스 선언이 예상과 다릅니다.')
            if name == 'ViewController.swift' and re.search(r'\bextensionBundleIdentifier\b', source):
                identifiers = re.findall(r'\b(?:let|var)\s+extensionBundleIdentifier\s*=\s*"([^"\r\n]+)"', source)
                if identifiers != [BUNDLE_ID + '.Extension']:
                    raise BuildError('앱 화면이 사용하는 Safari 확장 식별자가 기본값과 다릅니다.')
        info_paths = []
        for config_id, config in configs:
            settings = config['buildSettings']
            desired = {'PRODUCT_MODULE_NAME': module, 'PRODUCT_BUNDLE_IDENTIFIER': bundle_id}
            if config['name'] == 'Debug':
                if settings.get('ENABLE_DEBUG_DYLIB', 'YES') not in ('YES', 'NO'):
                    raise BuildError('생성된 Debug dylib 값이 예상과 다릅니다.')
                desired['ENABLE_DEBUG_DYLIB'] = 'NO'
            changes[config_id] = desired
            info_name = settings.get('INFOPLIST_FILE')
            if info_name:
                for prefix in ('$(SRCROOT)/', '$(PROJECT_DIR)/'):
                    if info_name.startswith(prefix):
                        info_name = info_name[len(prefix):]
                        break
                if '$' in info_name or '..' in Path(info_name).parts or Path(info_name).is_absolute():
                    raise BuildError('생성된 Info.plist 경로가 예상과 다릅니다.')
                info_paths.append(project.parent / info_name)
            elif module != 'NyangstaSave' or settings.get('GENERATE_INFOPLIST_FILE') != 'YES':
                raise BuildError('생성된 Info.plist 참조를 확인하지 못했습니다.')
        if info_paths and (len(info_paths) != 2 or info_paths[0] != info_paths[1]):
            raise BuildError('Debug·Release의 Info.plist 참조가 서로 다릅니다.')
        if info_paths:
            info = plistlib.loads(read(info_paths[0]))
            if info.get('CFBundleIdentifier', '$(PRODUCT_BUNDLE_IDENTIFIER)') != '$(PRODUCT_BUNDLE_IDENTIFIER)':
                raise BuildError('Info.plist의 고정 Bundle Identifier는 자동 변경하지 않습니다.')
            if module == 'NyangstaSaveExtension':
                extension = info.get('NSExtension', {})
                if (extension.get('NSExtensionPointIdentifier') != 'com.apple.Safari.web-extension'
                        or extension.get('NSExtensionPrincipalClass') != '$(PRODUCT_MODULE_NAME).SafariWebExtensionHandler'
                        or 'NSExtensionMainStoryboard' in extension):
                    raise BuildError('Safari 확장의 진입 클래스가 예상과 다릅니다.')

    storyboard = files['Main.storyboard'][0]
    story_bytes = read(storyboard)
    tree = ET.fromstring(story_bytes)
    story_text = story_bytes.decode('utf-8')
    for name in ('AppDelegate', 'ViewController'):
        nodes = [node for node in tree.iter() if node.get('customClass') == name]
        if len(nodes) != 1:
            raise BuildError('스토리보드의 클래스 참조를 하나로 확인하지 못했습니다.')
        if (nodes[0].get('customModuleProvider') not in (None, 'target')
                or unicodedata.normalize('NFC', nodes[0].get('customModule', APP_NAME)) not in (APP_NAME, 'NyangstaSave')):
            raise BuildError('스토리보드의 기존 모듈 참조가 예상과 다릅니다.')
        matches = list(re.finditer(r'<[A-Za-z_][^>]*\bcustomClass="' + name + r'"[^>]*>', story_text))
        if len(matches) != 1:
            raise BuildError('스토리보드 원문 참조가 예상과 다릅니다.')
        match = matches[0]
        tag = re.sub(r'\s+customModule(?:Provider)?="[^"]*"', '', match.group())
        tag = tag.replace('customClass="' + name + '"', 'customClass="' + name + '" customModule="NyangstaSave"')
        story_text = story_text[:match.start()] + tag + story_text[match.end():]
    expected_tree = ET.fromstring(story_bytes)
    for node in expected_tree.iter():
        if node.get('customClass') in ('AppDelegate', 'ViewController'):
            node.attrib.pop('customModuleProvider', None)
            node.set('customModule', 'NyangstaSave')
    if ET.canonicalize(story_text) != ET.canonicalize(ET.tostring(expected_tree, encoding='unicode')):
        raise BuildError('예상한 클래스 참조 이외의 XML 변경이 감지됐습니다.')

    text = original.decode('utf-8')
    spans = project_spans(text)['entries']['objects']['entries']
    expected = json.loads(json.dumps(data))
    edits = []
    newline = '\r\n' if '\r\n' in text else '\n'
    for config_id, desired in changes.items():
        settings = spans[config_id]['entries']['buildSettings']
        actual = objects[config_id]['buildSettings']
        if settings['kind'] != '{' or set(settings['entries']) != set(actual):
            raise BuildError('설정 원문과 해석 결과가 일치하지 않습니다.')
        additions = []
        for key, value in desired.items():
            expected['objects'][config_id]['buildSettings'][key] = value
            if actual.get(key) == value:
                continue
            if key in settings['entries']:
                node = settings['entries'][key]
                if node['kind'] in ('{', '('):
                    raise BuildError('변경 대상 설정이 문자열이 아닙니다.')
                edits.append((node['start'], node['end'], '"' + value + '"'))
            else:
                additions.append(key + ' = ' + value + ';')
        if additions:
            closing = settings['close']
            start = text.rfind('\n', 0, closing) + 1
            indent = text[start:closing]
            if indent.strip():
                edits.append((closing, closing, ' '.join(additions) + ' '))
            else:
                edits.append((start, start, ''.join(indent + '\t' + addition + newline for addition in additions)))
    for start, end, value in sorted(edits, reverse=True):
        text = text[:start] + value + text[end:]
    updates = {pbx: text.encode('utf-8'), storyboard: story_text.encode('utf-8')}
    staged = {}

    def unchanged():
        for path, (before, content) in dependencies.items():
            generated_path(path, boundary)
            info = path.stat()
            if ((info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns) != before
                    or path.read_bytes() != content):
                raise BuildError('정규화 중 생성 파일이 변경되어 중단합니다.')
    try:
        for path, content in updates.items():
            descriptor, name = tempfile.mkstemp(prefix='.nyangsta-normalize-', dir=path.parent)
            staged[path] = Path(name)
            with os.fdopen(descriptor, 'wb') as stream:
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
            os.chmod(name, stat.S_IMODE(path.stat().st_mode))
        if generated_project_data(staged[pbx]) != expected:
            raise BuildError('허용한 설정 이외의 프로젝트 변경이 감지됐습니다.')
        unchanged()
        for path, temporary in staged.items():
            generated_path(temporary, boundary)
            if temporary.read_bytes() != updates[path]:
                raise BuildError('정규화 임시 파일이 변경되어 중단합니다.')
        for path, temporary in staged.items():
            unchanged()
            os.replace(temporary, path)
            info = path.stat()
            dependencies[path] = ((info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns), updates[path])
    finally:
        for path in staged.values():
            path.unlink(missing_ok=True)
    return {'app_module': 'NyangstaSave', 'extension_module': 'NyangstaSaveExtension',
            'debug_dylib': 'NO', 'extension_bundle_identifier': BUNDLE_ID + '.Extension',
            'storyboard_module': 'NyangstaSave'}


def prepare(output, *, package=None, build=False, team=None, scheme=None):
    # Even an empty directory or symlink is preserved. Use a fresh explicit path.
    output = output.expanduser().absolute()
    if output.exists() or output.is_symlink():
        raise BuildError('출력 경로가 이미 있습니다. 기존 프로젝트를 보존하므로 새 --output 경로를 지정하세요.')
    if any(parent.is_symlink() for parent in output.parents):
        raise BuildError('출력 경로 상위에 심볼릭 링크가 있어 새 폴더를 만들지 않습니다.')
    if build:
        team = team or os.environ.get('DEVELOPMENT_TEAM')
        if not team or not re.fullmatch(r'[A-Z0-9]{10}', team):
            raise BuildError('--build에는 기존 인증서의 10자리 팀 ID(--team 또는 DEVELOPMENT_TEAM)가 필요합니다.')
    elif team or scheme:
        raise BuildError('--team과 --scheme은 --build와 함께 지정하세요.')
    packager, xcodebuild, codesign, version = discover_tools(build)
    archive_bytes, payloads = read_package(package.expanduser() if package else None)
    output.mkdir(parents=True, exist_ok=False)
    (output / 'Nyangsta-Safari.zip').write_bytes(archive_bytes)
    extension = output / 'Extension'
    extension.mkdir()
    for name, payload in payloads.items():
        (extension / name).write_bytes(payload)
    (output / 'Project').mkdir()
    run([
        packager, extension, '--project-location', output / 'Project', '--app-name', APP_NAME,
        '--bundle-identifier', BUNDLE_ID, '--swift', '--macos-only', '--copy-resources', '--no-open', '--no-prompt',
    ], timeout=120, log=output / 'packager.log')
    projects = list((output / 'Project').rglob('*.xcodeproj'))
    if len(projects) != 1 or not (projects[0] / 'project.pbxproj').is_file():
        raise BuildError('생성된 Xcode 프로젝트를 하나로 확인하지 못했습니다. packager.log를 확인하세요.')
    project = projects[0]
    try:
        normalization = normalize_generated_project(output, project)
    except (ValueError, KeyError, TypeError, AttributeError, ET.ParseError, ExpatError) as exc:
        raise BuildError('생성 프로젝트의 구조를 확인하지 못해 정규화를 중단했습니다.') from exc
    record = {
        'version': 1, 'state': 'project_generated', 'bundle_identifier': BUNDLE_ID,
        'package_sha256': hashlib.sha256(archive_bytes).hexdigest(),
        'packager': packager.name, 'xcode_version': version,
        'project': str(project.relative_to(output)),
        'installation_verified': False, 'safari_restart_verified': False,
        'normalization': normalization,
    }
    (output / 'build-record.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    if build:
        app, used_scheme = signed_build(xcodebuild, codesign, project, output, team, scheme)
        record.update(state='signed_build_verified', app=str(app.relative_to(output)), scheme=used_scheme)
        (output / 'build-record.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return record


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, epilog='앱 자동 설치·실행, 계정 로그인, 인증서 생성, 자동 프로비저닝은 하지 않습니다.')
    parser.add_argument('--output', required=True, type=Path, help='새 출력 폴더. 기존 폴더는 덮어쓰지 않습니다.')
    parser.add_argument('--package', type=Path, help='기존 Nyangsta-Safari.zip. 생략하면 공통 소스에서 새 ZIP을 생성합니다.')
    parser.add_argument('--build', action='store_true', help='기존 Apple Development 인증서로 수동 서명 빌드도 수행합니다.')
    parser.add_argument('--team', help='사용자가 지정한 기존 인증서의 팀 ID; 생략 시 DEVELOPMENT_TEAM 환경 변수.')
    parser.add_argument('--scheme', help='앱 scheme을 자동 선택할 수 없을 때 명시합니다.')
    args = parser.parse_args(argv)
    try:
        result = prepare(args.output, package=args.package, build=args.build, team=args.team, scheme=args.scheme)
    except (BuildError, OSError) as exc:
        print('오류: ' + str(exc), file=sys.stderr)
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    print('프로젝트/빌드 준비 결과입니다. Safari 설치·재시작 유지·실제 저장은 별도로 확인해야 합니다.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
