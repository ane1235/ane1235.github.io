#!/usr/bin/env python3
"""Create and open the Safari Xcode project on this Mac; do not build or install."""
from __future__ import annotations

from datetime import datetime
import importlib.util
import os
from pathlib import Path
import platform
import subprocess
import sys


ROOT = Path(__file__).resolve().parent.parent
STANDARD_DEVELOPER = Path('/Applications/Xcode.app/Contents/Developer')
OPEN_TOOL = '/usr/bin/open'


class PreparationError(Exception):
    """An actionable local preparation failure."""


def load_builder():
    spec = importlib.util.spec_from_file_location('nyangsta_local_safari_builder', ROOT / 'scripts/build-safari-app.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def fresh_output(downloads):
    stem = 'Nyangsta-Safari-Project-' + datetime.now().strftime('%Y%m%d-%H%M%S')
    for index in range(1000):
        candidate = downloads / (stem + ('-' + str(index) if index else ''))
        if not candidate.exists() and not candidate.is_symlink():
            return candidate
    raise PreparationError('새 출력 폴더를 정하지 못했습니다. Downloads 폴더를 확인하세요.')


def prepare_local():
    if platform.system() != 'Darwin':
        raise PreparationError('이 준비 도구는 Xcode가 설치된 Mac에서 실행하세요. 서버에서는 실행하지 않습니다.')
    if sys.version_info < (3, 9):
        raise PreparationError('Python 3.9 이상이 필요합니다. 설치한 Xcode의 초기 설정을 확인하세요.')
    builder = load_builder()
    output = fresh_output(Path.home() / 'Downloads')
    # This process and its children only; no sudo or global xcode-select change.
    previous_developer = os.environ.get('DEVELOPER_DIR')
    if (STANDARD_DEVELOPER / 'usr/bin/xcodebuild').is_file():
        os.environ['DEVELOPER_DIR'] = str(STANDARD_DEVELOPER)
    try:
        print('Safari Xcode 프로젝트를 준비합니다. 준비 도구 v2 · 앱 서명·설치는 다음 단계입니다.', flush=True)
        # Do not pass --build, team, certificate or provisioning options.
        record = builder.prepare(output)
    except builder.BuildError as exc:
        raise PreparationError(str(exc) + '\n출력 예정 위치: ' + str(output)) from exc
    finally:
        if previous_developer is None:
            os.environ.pop('DEVELOPER_DIR', None)
        else:
            os.environ['DEVELOPER_DIR'] = previous_developer
    relative = Path(record.get('project', ''))
    project = output / relative
    if (record.get('state') != 'project_generated' or relative.is_absolute() or '..' in relative.parts
            or project.suffix != '.xcodeproj' or not (project / 'project.pbxproj').is_file()
            or not project.resolve().is_relative_to(output.resolve())):
        raise PreparationError('생성된 프로젝트 경로를 확인하지 못했습니다. 출력 폴더를 확인하세요: ' + str(output))
    try:
        opened = subprocess.run(
            [OPEN_TOOL, str(project)], stdin=subprocess.DEVNULL, capture_output=True,
            text=True, check=False, shell=False, timeout=30,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise PreparationError('프로젝트는 생성했지만 Xcode를 열지 못했습니다. 직접 열 경로: ' + str(project)) from exc
    if opened.returncode:
        raise PreparationError('프로젝트는 생성했지만 Xcode를 열지 못했습니다. 직접 열 경로: ' + str(project))
    print('프로젝트 생성 완료: ' + str(project))
    print('프로젝트 열기를 요청했습니다. Xcode에 프로젝트가 보이는지 확인해 주세요.')
    print('앱 설치 완료가 아닙니다.')
    print('다음 확인: 앱·확장 서명 설정 → 빌드·설치 → Safari 재시작 후 도우미 유지 및 저장 검증.')
    print('위 생성 경로와 Xcode 왼쪽의 냥스타저장 프로젝트 표시를 확인해 알려주세요. 오류가 있으면 오류 문구를 알려주세요.')
    return record


def main():
    try:
        prepare_local()
    except (PreparationError, OSError) as exc:
        print('오류: ' + str(exc), file=sys.stderr)
        print('앱 서명·설치·Safari 재시작 검증은 완료되지 않았습니다.', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
