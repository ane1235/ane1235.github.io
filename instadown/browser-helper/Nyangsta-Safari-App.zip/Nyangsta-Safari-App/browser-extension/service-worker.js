import "./protocol.js";
const P = globalThis.NyangstaProtocol;

export function createRequestHandler(api, now = Date.now, timers = globalThis) {
  const seen = new Map();
  const pending = new Map();
  let storyBusy = false;
  let lastHomeOpened = -Infinity;
  function validSender(sender) {
    return sender?.id === api.runtime.id && sender.frameId === 0 && Number.isInteger(sender.tab?.id) &&
      !sender.tab.incognito && P.allowedWebURL(sender.url) && P.allowedWebURL(sender.tab.url) &&
      new URL(sender.url).origin === new URL(sender.tab.url).origin;
  }
  async function resolveStory(message) {
    if (storyBusy) return P.failure("browser_busy");
    storyBusy = true;
    let expired = false, timer;
    const checkDeadline = () => { if (expired) P.fail("browser_timeout"); };
    const work = async () => {
      const tabs = (await api.tabs.query({url: "https://www.instagram.com/*"})).filter(tab => !tab.incognito && Number.isInteger(tab.id));
      checkDeadline();
      if (!tabs.length) {
        if (now() - lastHomeOpened > 10000) {
          lastHomeOpened = now();
          await api.tabs.create({url: "https://www.instagram.com/", active: true});
          checkDeadline();
        }
        return P.failure("browser_instagram_tab_required");
      }
      tabs.sort((a, b) => Number(b.active) - Number(a.active) || (b.lastAccessed || 0) - (a.lastAccessed || 0));
      const target = {tabId: tabs[0].id, frameIds: [0]};
      await api.scripting.executeScript({target, world: "ISOLATED", files: ["protocol.js", "instagram-collector.js"]});
      checkDeadline();
      const results = await api.scripting.executeScript({
        target, world: "ISOLATED",
        func: async url => globalThis.NyangstaCollector.resolveStory(url),
        args: [message.url]
      });
      checkDeadline();
      if (!Array.isArray(results) || results.length !== 1 || results[0].frameId !== 0) return P.failure("browser_bridge_unavailable");
      const result = results[0].result;
      if (result?.ok === true) return {ok: true, story: P.validateStory(result.story, message.url)};
      return P.failure(result?.error_code);
    };
    try {
      return await Promise.race([
        work(),
        new Promise(resolve => { timer = timers.setTimeout(() => { expired = true; resolve(P.failure("browser_timeout")); }, 30000); })
      ]);
    } catch (error) {
      return P.failure(Object.hasOwn(P.MESSAGES, error?.code) ? error.code : "browser_bridge_unavailable");
    } finally { timers.clearTimeout(timer); storyBusy = false; }
  }
  return async function handleRequest(raw, sender) {
    try {
      if (!validSender(sender)) return P.failure("invalid_bridge_request");
      const message = P.validateMessage(raw);
      const key = `${sender.tab.id}:${message.id}`;
      if (pending.has(key)) return pending.get(key);
      const clock = now();
      for (const [id, time] of seen) if (clock - time > 120000) seen.delete(id);
      if (seen.has(key)) return P.failure("browser_duplicate_request");
      if (seen.size >= 256) seen.delete(seen.keys().next().value);
      seen.set(key, clock);
      if (message.type === "ping") return {ok: true};
      const work = resolveStory(message);
      pending.set(key, work);
      try { return await work; } finally { pending.delete(key); }
    } catch (error) { return P.failure(error?.code); }
  };
}

if (globalThis.chrome?.runtime?.onMessage) {
  const handleRequest = createRequestHandler(chrome);
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    handleRequest(message, sender).then(sendResponse, () => sendResponse(P.failure("browser_bridge_unavailable")));
    return true;
  });
}
