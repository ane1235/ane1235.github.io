/* This script reads only explicit webapp messages. It never inspects form values. */
(() => {
  "use strict";
  const P = globalThis.NyangstaProtocol;
  function install(windowObject, runtime, timers = globalThis) {
    if (!P.allowedWebURL(windowObject.location.href)) return () => {};
    const seen = new Map();
    let active = 0;
    const listener = async event => {
      if (event.source !== windowObject || event.origin !== windowObject.location.origin || !P.allowedWebURL(windowObject.location.href)) return;
      const raw = event.data;
      if (!P.isRecord(raw) || raw.source !== "nyangsta-web" || raw.version !== 1 || !P.UUID.test(raw.id || "")) return;
      const now = Date.now();
      for (const [key, time] of seen) if (now - time > 120000) seen.delete(key);
      if (seen.has(raw.id)) return;
      if (seen.size >= 256) seen.delete(seen.keys().next().value);
      seen.set(raw.id, now);
      const origin = event.origin;
      const send = result => {
        if (windowObject.location.origin === origin && P.allowedWebURL(windowObject.location.href)) {
          windowObject.postMessage({source: "nyangsta-extension", version: 1, id: raw.id, ...result}, origin);
        }
      };
      let message;
      try { message = P.validateMessage(raw); }
      catch (error) { send(P.failure(error?.code)); return; }
      if (active >= 4) { send(P.failure("browser_busy")); return; }
      active += 1;
      let timer;
      try {
        const result = await Promise.race([
          runtime.sendMessage(message),
          new Promise(resolve => { timer = timers.setTimeout(() => resolve(P.failure("browser_timeout")), 35000); })
        ]);
        if (result?.ok !== true) send(P.failure(result?.error_code));
        else if (message.type === "ping") send({ok: true});
        else send({ok: true, story: P.validateStory(result.story, message.url)});
      } catch (error) { send(P.failure(error?.code)); }
      finally { timers.clearTimeout(timer); active -= 1; }
    };
    windowObject.addEventListener("message", listener);
    return () => windowObject.removeEventListener("message", listener);
  }
  globalThis.NyangstaWebBridge = Object.freeze({install});
  if (globalThis.window && globalThis.chrome?.runtime) install(window, chrome.runtime);
})();
