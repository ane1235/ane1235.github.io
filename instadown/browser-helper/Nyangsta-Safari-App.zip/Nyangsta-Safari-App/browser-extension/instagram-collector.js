/* Injected only into an existing Instagram tab, in Chrome's ISOLATED world. */
(() => {
  "use strict";
  const P = globalThis.NyangstaProtocol;
  const MAX_RESPONSE_BYTES = 2 * 1024 * 1024;
  const FETCH_TIMEOUT_MS = 18000;

  function exactMediaID(item) {
    const ids = [];
    if (typeof item.id === "string" && /^[1-9][0-9]{0,39}(?:_[1-9][0-9]{0,39})?$/.test(item.id)) ids.push(item.id.split("_")[0]);
    else if (typeof item.id === "number" && Number.isSafeInteger(item.id) && item.id > 0) ids.push(String(item.id));
    else if (item.id !== undefined && !(typeof item.id === "number" && Number.isInteger(item.id))) P.fail("browser_story_unsupported");
    if (typeof item.pk === "string" && P.ID.test(item.pk)) ids.push(item.pk);
    else if (typeof item.pk === "number" && Number.isSafeInteger(item.pk) && item.pk > 0) ids.push(String(item.pk));
    else if (item.pk !== undefined && !(typeof item.pk === "number" && Number.isInteger(item.pk))) P.fail("browser_story_unsupported");
    // Unsafe JSON numbers cannot establish identity; a separate exact string is required.
    if (!ids.length) P.fail("browser_story_unsupported");
    if (ids.some(id => id !== ids[0])) P.fail("browser_story_mismatch");
    return ids[0];
  }
  function mediaCandidate(candidates) {
    if (!Array.isArray(candidates) || candidates.length === 0 || candidates.length > 100) P.fail("browser_story_unsupported");
    const valid = candidates.filter(candidate => P.isRecord(candidate) &&
      Number.isSafeInteger(candidate.width) && candidate.width > 0 && candidate.width <= 32768 &&
      Number.isSafeInteger(candidate.height) && candidate.height > 0 && candidate.height <= 32768 &&
      P.safeMediaURL(candidate.url));
    if (!valid.length) P.fail("browser_story_unsupported");
    valid.sort((a, b) => b.width * b.height - a.width * a.height);
    return P.safeMediaURL(valid[0].url);
  }
  function storyFromResponse(data, requestedURL) {
    const expected = P.parseStoryURL(requestedURL);
    if (!P.isRecord(data) || !Array.isArray(data.items) || data.items.length > 250) P.fail("browser_story_unsupported");
    if (!data.items.length) P.fail("browser_story_not_found");
    const matches = data.items.filter(item => P.isRecord(item) && exactMediaID(item) === expected.story_id);
    if (matches.length !== 1) P.fail("browser_story_mismatch");
    const item = matches[0];
    if (!P.isRecord(item.user) || typeof item.user.username !== "string" || !P.USERNAME.test(item.user.username) || item.user.username.toLowerCase() !== expected.owner) P.fail("browser_story_mismatch");
    let kind, mediaURL;
    if (item.media_type === 2) {
      kind = "video";
      mediaURL = mediaCandidate(item.video_versions);
    } else if (item.media_type === 1) {
      // Do not silently turn a video-bearing response into a still thumbnail.
      if (Array.isArray(item.video_versions) && item.video_versions.length) P.fail("browser_story_unsupported");
      kind = "photo";
      mediaURL = mediaCandidate(item.image_versions2?.candidates);
    } else P.fail("browser_story_unsupported");
    return P.validateStory({version: 1, ...expected, taken_at: item.taken_at, kind, media_url: mediaURL}, expected.source_url);
  }
  async function boundedJSON(response) {
    if (!/\bapplication\/(?:[a-z0-9.+-]*\+)?json\b/i.test(response.headers.get("content-type") || "")) P.fail("browser_access_unconfirmed");
    const length = Number(response.headers.get("content-length"));
    if (length > MAX_RESPONSE_BYTES) P.fail("browser_story_unsupported");
    if (!response.body?.getReader) P.fail("browser_story_unsupported");
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let bytes = 0, text = "";
    try {
      for (;;) {
        const chunk = await reader.read();
        if (chunk.done) break;
        bytes += chunk.value.byteLength;
        if (bytes > MAX_RESPONSE_BYTES) {
          await reader.cancel();
          P.fail("browser_story_unsupported");
        }
        text += decoder.decode(chunk.value, {stream: true});
      }
      text += decoder.decode();
      return JSON.parse(text);
    } finally { reader.releaseLock(); }
  }
  function responseError(data, status) {
    const marker = typeof data?.message === "string" ? data.message.toLowerCase().trim() : "";
    if (status === 429 || ["rate_limit_error", "please wait a few minutes before you try again."].includes(marker)) return "browser_rate_limited";
    if (data?.challenge || ["challenge_required", "checkpoint_required"].includes(marker)) return "browser_challenge_required";
    if (status === 401 || marker === "login_required") return "browser_login_required";
    if (status === 404) return "browser_story_not_found";
    if (status < 200 || status >= 300 || data?.status === "fail") return "browser_access_unconfirmed";
    return null;
  }
  function ownerProfile(data, expectedOwner) {
    const user = data?.data?.user;
    if (!P.isRecord(user) || typeof user.username !== "string" || user.username.toLowerCase() !== expectedOwner) P.fail("browser_story_mismatch");
    return {id: exactMediaID(user), user};
  }
  function storyFromReels(data, owner, expectedURL) {
    let reel;
    if (P.isRecord(data?.reels)) reel = data.reels[owner.id];
    else if (Array.isArray(data?.reels_media) && data.reels_media.length <= 20) {
      const matches = data.reels_media.filter(value => P.isRecord(value) && exactMediaID(value) === owner.id);
      if (matches.length !== 1) P.fail("browser_story_not_found");
      reel = matches[0];
    }
    if (!P.isRecord(reel) || !Array.isArray(reel.items) || !reel.items.length) P.fail("browser_story_not_found");
    if (!P.isRecord(reel.user) || reel.user.username?.toLowerCase() !== owner.user.username.toLowerCase()) P.fail("browser_story_mismatch");
    if (exactMediaID(reel.user) !== owner.id) P.fail("browser_story_mismatch");
    if (reel.id !== undefined && exactMediaID(reel) !== owner.id) P.fail("browser_story_mismatch");
    // Owner inherited only from an exact, verified owner reel, never from a different profile.
    return storyFromResponse({items: reel.items.map(item => P.isRecord(item) ? {...item, user: item.user ?? reel.user} : item)}, expectedURL);
  }
  async function resolveStory(requestedURL, environment = {}) {
    const controller = new AbortController();
    const timeout = (environment.setTimeout || setTimeout)(() => controller.abort(), FETCH_TIMEOUT_MS);
    try {
      const expected = P.parseStoryURL(requestedURL);
      const location = environment.location || globalThis.location;
      if (location?.origin !== "https://www.instagram.com") P.fail("browser_access_unconfirmed");
      if (/^\/accounts\/login(?:\/|$)/.test(location.pathname)) P.fail("browser_login_required");
      if (/^\/(?:challenge|checkpoint)(?:\/|$)/.test(location.pathname)) P.fail("browser_challenge_required");
      const read = async path => {
        const response = await (environment.fetch || fetch)(`https://www.instagram.com${path}`, {
          method: "GET", credentials: "same-origin", mode: "same-origin", redirect: "error", cache: "no-store",
          headers: {"Accept": "application/json", "X-IG-App-ID": "936619743392459", "X-Requested-With": "XMLHttpRequest"},
          signal: controller.signal
        });
        if (response.status === 429) P.fail("browser_rate_limited");
        if (response.status === 401) P.fail("browser_login_required");
        if (response.status === 404) P.fail("browser_story_not_found");
        const data = await boundedJSON(response);
        const code = responseError(data, response.status);
        if (code) P.fail(code);
        return data;
      };
      try {
        const data = await read(`/api/v1/media/${expected.story_id}/info/`);
        return {ok: true, story: storyFromResponse(data, expected.source_url)};
      } catch (error) {
        // Only a missing/unsupported direct item permits this one owner-scoped fallback.
        // Authentication, ambiguous access, identity mismatch and 429 stop immediately.
        if (!["browser_story_not_found", "browser_story_unsupported"].includes(error?.code)) throw error;
      }
      const profile = ownerProfile(await read(`/api/v1/users/web_profile_info/?username=${encodeURIComponent(expected.owner)}`), expected.owner);
      const reels = await read(`/api/v1/feed/reels_media/?reel_ids=${profile.id}`);
      return {ok: true, story: storyFromReels(reels, profile, expected.source_url)};
    } catch (error) {
      if (controller.signal.aborted || error?.name === "AbortError") return P.failure("browser_timeout");
      return P.failure(Object.hasOwn(P.MESSAGES, error?.code) ? error.code : "browser_access_unconfirmed");
    } finally { (environment.clearTimeout || clearTimeout)(timeout); }
  }
  globalThis.NyangstaCollector = Object.freeze({exactMediaID, storyFromResponse, ownerProfile, storyFromReels, responseError, resolveStory});
})();
