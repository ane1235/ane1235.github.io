/* Shared isolated-world policy. No page data, cookies, or credentials are read. */
(() => {
  "use strict";
  const MESSAGES = Object.freeze({
    invalid_bridge_request: "브라우저 도우미 요청 형식을 확인할 수 없습니다.",
    invalid_story_url: "계정과 숫자 ID가 포함된 개별 Instagram 스토리 링크를 입력하세요.",
    browser_instagram_tab_required: "Instagram 탭을 열었습니다. 같은 브라우저 프로필에서 로그인한 뒤 저장을 다시 실행하세요.",
    browser_login_required: "같은 브라우저 프로필의 Instagram 탭에서 로그인한 뒤 다시 실행하세요.",
    browser_challenge_required: "Instagram 탭에서 추가 인증을 마친 뒤 다시 실행하세요.",
    browser_rate_limited: "Instagram이 브라우저 요청을 제한했습니다. 자동 재시도하지 않았습니다. 잠시 후 다시 실행하세요.",
    browser_access_unconfirmed: "브라우저에서 Instagram 응답을 확인하지 못했습니다. Instagram 탭에서 해당 스토리가 열리는지 확인하세요.",
    browser_story_not_found: "Instagram이 해당 스토리를 반환하지 않았습니다. 링크와 Instagram에서 열리는 상태를 확인하세요.",
    browser_story_mismatch: "Instagram 응답의 스토리 ID 또는 계정이 입력한 링크와 일치하지 않아 중단했습니다.",
    browser_story_unsupported: "스토리의 원본 미디어 또는 게시 정보를 정확히 확인하지 못해 저장을 중단했습니다.",
    browser_timeout: "Instagram 브라우저 조회 시간이 초과됐습니다. 자동 재시도하지 않았습니다.",
    browser_bridge_unavailable: "브라우저 도우미와 연결하지 못했습니다. 도우미를 확인하고 웹앱을 새로고침하세요.",
    browser_busy: "다른 스토리를 조회 중입니다. 완료된 뒤 다시 실행하세요.",
    browser_duplicate_request: "이미 처리한 브라우저 요청입니다. 새 저장 요청으로 다시 실행하세요."
  });
  const UUID = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
  const USERNAME = /^[A-Za-z0-9_][A-Za-z0-9_.]{0,29}$/;
  const ID = /^[1-9][0-9]{0,39}$/;
  const STORY_ID = /^[0-9]{5,30}$/;
  const STORY_KEYS = ["version", "source_url", "owner", "story_id", "taken_at", "kind", "media_url"];

  function failure(code) {
    const safe = Object.hasOwn(MESSAGES, code) ? code : "browser_bridge_unavailable";
    return {ok: false, error_code: safe, message: MESSAGES[safe]};
  }
  function fail(code) {
    const error = new Error(MESSAGES[code] || MESSAGES.browser_bridge_unavailable);
    error.code = Object.hasOwn(MESSAGES, code) ? code : "browser_bridge_unavailable";
    throw error;
  }
  function isRecord(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
  }
  function strictURL(value) {
    if (typeof value !== "string" || value.length > 8192 || /[\x00-\x20\x7f\\]/.test(value)) return null;
    try {
      const url = new URL(value);
      return url.username || url.password ? null : url;
    } catch { return null; }
  }
  function allowedWebURL(value) {
    const url = strictURL(value);
    if (!url) return false;
    if (url.origin === "https://ane1235.github.io") return url.pathname === "/instadown/";
    return [
      "https://kayenpc.tail730e13.ts.net:8443",
      "https://kayenpc.tail730e13.ts.net:10000",
      "http://127.0.0.1:8765",
      "http://192.168.0.36:8765"
    ].includes(url.origin) && url.pathname === "/";
  }
  function parseStoryURL(value) {
    const url = strictURL(value);
    if (!url || url.protocol !== "https:" || url.port || !["www.instagram.com", "instagram.com", "m.instagram.com"].includes(url.hostname)) fail("invalid_story_url");
    const match = /^\/stories\/([^/]+)\/([^/]+)\/?$/.exec(url.pathname);
    if (!match || !USERNAME.test(match[1]) || !STORY_ID.test(match[2])) fail("invalid_story_url");
    const owner = match[1].toLowerCase();
    if (["highlights", "me"].includes(owner)) fail("invalid_story_url");
    return {owner, story_id: match[2], source_url: `https://www.instagram.com/stories/${match[1]}/${match[2]}/`};
  }
  function safeMediaURL(value) {
    const url = strictURL(value);
    if (!url || url.protocol !== "https:" || url.port || url.hash) return null;
    if (!/^[a-z0-9]+(?:[a-z0-9.-]*[a-z0-9])?$/.test(url.hostname) || url.hostname.includes("..")) return null;
    if (!["cdninstagram.com", "fbcdn.net"].some(domain => url.hostname.endsWith(`.${domain}`))) return null;
    return url.href;
  }
  function validateMessage(value) {
    if (!isRecord(value) || value.source !== "nyangsta-web" || value.version !== 1 || !UUID.test(value.id || "")) fail("invalid_bridge_request");
    if (Object.keys(value).some(key => !["source", "version", "id", "type", "url"].includes(key))) fail("invalid_bridge_request");
    if (value.type === "ping" && value.url === undefined) return {source: value.source, version: 1, id: value.id, type: "ping"};
    if (value.type !== "resolveStory") fail("invalid_bridge_request");
    const story = parseStoryURL(value.url);
    return {source: value.source, version: 1, id: value.id, type: value.type, url: story.source_url};
  }
  function validateStory(value, expectedURL) {
    if (!isRecord(value) || Object.keys(value).length !== STORY_KEYS.length || STORY_KEYS.some(key => !Object.hasOwn(value, key))) fail("browser_story_unsupported");
    const expected = parseStoryURL(expectedURL);
    if (value.version !== 1 || value.source_url !== expected.source_url || value.owner !== expected.owner || value.story_id !== expected.story_id) fail("browser_story_mismatch");
    if (!Number.isSafeInteger(value.taken_at) || value.taken_at < 1262304000 || value.taken_at > 253402300799 || !["photo", "video"].includes(value.kind)) fail("browser_story_unsupported");
    const mediaURL = safeMediaURL(value.media_url);
    if (!mediaURL || mediaURL !== value.media_url) fail("browser_story_unsupported");
    return {version: 1, source_url: expected.source_url, owner: expected.owner, story_id: expected.story_id, taken_at: value.taken_at, kind: value.kind, media_url: mediaURL};
  }
  globalThis.NyangstaProtocol = Object.freeze({UUID, USERNAME, ID, MESSAGES, failure, fail, isRecord, allowedWebURL, parseStoryURL, safeMediaURL, validateMessage, validateStory});
})();
