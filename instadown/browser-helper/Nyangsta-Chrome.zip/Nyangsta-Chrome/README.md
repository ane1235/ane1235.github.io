# 냥스타저장 브라우저 도우미

Mac Chrome에서 냥스타저장과 Instagram을 **같은 Chrome 프로필**로 사용하는 경우를 위한 Manifest V3 확장이다. 웹앱의 개별 스토리 저장 요청을 받아, 기존 Instagram 탭에서 현재 로그인을 이용해 조회한다. 계정 쿠키를 읽거나 서버로 보내지 않는다. 웹앱 접속 인증을 추가하지 않는다.

현재 버전은 Mac Chrome 우선 구현이다. Safari·iOS·iPadOS의 설치본이 아니며 다른 브라우저에서의 지원을 검증하지 않았다. Chrome 120 이상을 선언한다. 실제 Instagram 응답과 실제 미디어 다운로드 성공은 별도 검증해야 한다.

## 설치와 사용

1. 이 디렉터리를 Mac의 계속 보관할 폴더에 둔다. `manifest.json`이 있는 폴더를 선택해야 한다.
2. **Instagram에 로그인한 Chrome 프로필**에서 `chrome://extensions`를 연다.
3. 개발자 모드를 켜고 **압축해제된 확장 프로그램을 로드합니다**를 선택해 이 폴더를 지정한다. Chrome이 표시하는 사이트 접근 권한을 확인한다.
4. 같은 프로필의 Instagram 탭과 냥스타저장 웹앱을 연다. 설치 전에 열었던 웹앱은 새로고침한다.
5. 웹앱에 `https://www.instagram.com/stories/계정/숫자ID/` 링크를 입력하고 저장한다. 일반 게시물·릴스는 기존 서버 경로를 사용한다.

이 문서는 수동 설치 절차다. 개발 중 사용자 브라우저의 보호 설정을 자동 변경하거나 확장을 자동 설치하지 않았다. 변경된 확장은 `chrome://extensions`에서 새로고침하고 웹앱도 새로고침한다.

Instagram 탭이 없으면 홈 탭 **하나**를 열고 로그인 안내를 반환한다. 스토리 화면을 자동으로 열거나 조회 완료(읽음) API를 호출하지 않는다. 사용자에게 홈 탭을 준비하도록 안내한 요청은 자동 재시도하지 않는다.

## 권한과 적용 범위

- 확장 API 권한: `scripting`.
- Instagram host 권한: `https://www.instagram.com/*`.
- 웹앱 콘텐츠 스크립트: 아래 URL만 실제 요청을 처리한다. manifest match pattern은 port를 세분할 수 없으므로 코드에서 origin·port·경로를 다시 검사한다.
  - `https://ane1235.github.io/instadown/`
  - `https://kayenpc.tail730e13.ts.net:8443/`
  - `https://kayenpc.tail730e13.ts.net:10000/`
  - 테스트용 `http://127.0.0.1:8765/`
- 위 정확한 경로의 query/fragment는 허용한다. 다른 경로·origin·port는 거절한다.
- `cookies`, `tabs`, `debugger`, 전체 사이트 host 권한을 요청하지 않는다. 시크릿 모드는 지원하지 않는다.
- 확장 ID 고정, 외부 서버 스크립트, `externally_connectable`, 네트워크 전체 감시, localStorage 접근을 사용하지 않는다.

`tabs.query`로 Instagram 탭을 찾고 두 번의 `scripting.executeScript`를 사용한다. 첫 단계는 로컬 파일을 `ISOLATED` world에 주입하고 두 번째 단계는 조회 함수를 호출한다. 요청 URL·소유자·미디어의 최소 결과를 다시 검증한 뒤 웹앱에 돌려준다. 공개 웹앱 페이지의 메시지를 임의 URL fetch 프록시로 사용하지 않는다.

## 웹앱 메시지 계약

웹앱은 자신의 origin을 targetOrigin으로 지정해 보낸다. UUID는 요청마다 새로 만든다. 초기 `ping`은 Instagram 요청을 만들지 않는다.

```js
window.postMessage({
  source: 'nyangsta-web', version: 1,
  id: crypto.randomUUID(), type: 'ping'
}, location.origin);

window.postMessage({
  source: 'nyangsta-web', version: 1,
  id: crypto.randomUUID(), type: 'resolveStory',
  url: 'https://www.instagram.com/stories/example.owner/1234567890123456789/'
}, location.origin);
```

응답은 같은 창·origin에 게시한다. 수신자는 `event.source === window`, `event.origin === location.origin`, source·version·요청 ID를 확인해야 한다.

```js
{
  source: 'nyangsta-extension', version: 1, id: '<request UUID>', ok: true,
  story: {
    version: 1,
    source_url: 'https://www.instagram.com/stories/example.owner/1234567890123456789/',
    owner: 'example.owner', story_id: '1234567890123456789',
    taken_at: 1789580000, kind: 'photo',
    media_url: 'https://example.cdninstagram.com/example.jpg'
  }
}
```

`ping` 성공에는 `story`가 없다. 오류는 `ok: false, error_code, message`를 포함한다. upstream 본문·예외 문자열·쿠키·전체 프로필·관계 목록은 반환하지 않는다. `story`는 위 **7개 필드만** 포함한다. 예시 데이터와 도메인은 합성이다.

- 입력은 HTTPS `instagram.com`, `www.instagram.com`, `m.instagram.com`의 개별 스토리 경로만 허용한다. 하이라이트·계정 전체 스토리 링크는 받지 않는다.
- source_url은 `www.instagram.com`과 끝 `/`로 정규화하고 query/fragment를 제거한다. 계정 경로의 원래 대소문자는 유지하고 `owner` 비교값은 소문자로 만든다.
- story_id는 5~30자리 숫자 문자열이다. JavaScript Number로 바꾸지 않는다. 응답 JSON의 unsafe numeric pk는 정확한 문자열 id를 대체할 수 없다.
- taken_at은 2010년 이후 정수 Unix 초다. 브라우저에서 시간대를 변환하거나 파일명을 만들지 않는다.
- kind는 `photo` 또는 `video`다. 영상의 썸네일을 영상 대신 반환하지 않는다.
- media_url은 HTTPS `*.cdninstagram.com` 또는 `*.fbcdn.net`만 허용하며 사용자정보·다른 port·fragment를 거절한다. 이 URL은 한 미디어 접근정보이므로 서버에서도 로그 노출을 피하고 재검증해야 한다.

## 조회 범위와 중단 조건

1. `GET /api/v1/media/{story_id}/info/`에서 정확한 ID·계정·게시시각·미디어를 확인한다.
2. 단일 응답이 404·빈 items·미지원 구조일 때에만 해당 계정의 `GET /api/v1/users/web_profile_info/?username=...`를 조회한다.
3. 정확한 username·user ID를 확인한 뒤 `GET /api/v1/feed/reels_media/?reel_ids={user_id}` 한 건에서 요청 ID 하나만 선택한다. `reels[user_id]`와 `reels_media` 응답 구조를 지원한다. 전체 계정 feed, 스토리 tray, 다른 계정은 조회하지 않는다.

각 요청은 Instagram 탭에서 `credentials: 'same-origin'`, `mode: 'same-origin'`, `redirect: 'error'`로 실행한다. 브라우저가 적절한 쿠키를 자동 첨부한다. `Cookie`, `Authorization`, `X-CSRFToken` 값을 추출·설정하지 않는다. `X-IG-App-ID`는 upstream에서 확인한 공개 웹앱 식별자이며 로그인 비밀값이 아니다.

429, 명시적 로그인·추가 인증, 원인 불명 403/접근 실패, ID·소유자 불일치가 발생하면 즉시 중단한다. 원인 불명 실패를 비공개·만료로 단정하지 않는다. fallback은 한 번이며 전체 최대 3개의 GET이다. Instagram 조회 전체에 18초 제한, worker에 30초 제한, 웹 브릿지에 35초 제한을 둔다. worker가 늦게 끝난 이전 query/injection으로 추가 단계를 실행하지 않게 검사한다. 동일 UUID 중복과 동시 조회를 제한한다.

이 API는 Meta의 공식 지원 API가 아니다. Instagram이 형식·헤더·접근 정책을 변경하면 실패할 수 있다. 서버 IP 요청을 브라우저 IP로 옮기는 것이 429 해제나 로그인 수락을 보장하지 않는다. 사진에 덧붙인 음악, DASH 전용 영상, 원본 촬영 파일과 동등한 화질, 브라우저 확장 설치 완료·실제 Instagram 성공은 이 단위 테스트의 보장 범위가 아니다.

## 검증

외부 패키지 설치 없이 Node 20 이상에서 실행한다.

```sh
node --test tests/*.test.js
```

2026-09-17: **46개 검사 통과**. 정확한 19자리 ID, 사진/영상 선택, 소유자 검증, 두 fallback 구조, 429 뒤 추가 요청 없음, 비밀값 없는 오류, URL/메시지 경계, 동일 창·origin, 중복 요청, timeout·늦은 응답, worker busy 해제를 합성 응답으로 확인했다. 실제 Instagram에 접근하는 테스트는 포함하지 않는다. 실제 Chrome 로드·웹앱 연동·실제 미디어 저장 증거는 프로젝트의 `docs/STATUS.md`를 기준으로 구분한다.

## 조사 근거와 라이선스

2026-09-17 현재 아래 공식 문서와 upstream 원문을 확인했다. API 경로·응답 필드·제약을 확인하는 기술 자료로 사용했고, 제3자 소스 코드를 복사하지 않고 이 확장을 작성했다.

- [Chrome content scripts](https://developer.chrome.com/docs/extensions/develop/concepts/content-scripts): isolated world, 페이지 origin에서의 스크립트 실행.
- [Chrome cross-origin network requests](https://developer.chrome.com/docs/extensions/develop/concepts/network-requests): 콘텐츠 스크립트의 origin 제한과 임의 fetch 프록시를 만들지 말아야 하는 이유.
- [Chrome messaging](https://developer.chrome.com/docs/extensions/develop/concepts/messaging): 웹페이지·콘텐츠 스크립트·worker 전달과 신뢰 경계. 표시 갱신일 2025-12-03.
- [Chrome service worker lifecycle](https://developer.chrome.com/docs/extensions/develop/concepts/service-workers/lifecycle): 종료 가능한 worker와 유한 작업 시간.
- [Chrome unpacked extension 설치](https://developer.chrome.com/docs/extensions/get-started/tutorial/hello-world#load-unpacked): 수동 개발자 모드 설치.
- [MDN HttpOnly](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Set-Cookie#httponly): JavaScript로 읽을 수 없는 쿠키도 허용된 fetch에 브라우저가 첨부함.
- [gallery-dl v1.32.12 Instagram 원문](https://github.com/mikf/gallery-dl/blob/v1.32.12/gallery_dl/extractor/instagram.py): www origin의 media/info·웹앱 ID·미디어 필드. GPL-2.0 upstream이며 경로·필드 검토에만 사용.
- [SocialSnag 고정 commit 원문](https://github.com/jamditis/socialsnag/blob/1a0a1ded60807c89507f52c1b2d71d9f001a2ded/src/platforms/instagram-api.js): `reels_media` 구조, 19자리 pk의 JSON Number 정밀도 손실, 정확한 개별 ID 선택. 조회 당시 MIT 라이선스로 확인된 upstream.
- [Instagram-Downloader 고정 commit 원문](https://github.com/hoaianle/Instagram-Downloader/blob/1b46d0772e4bee5ccdb939c817107ff89843d005/src/js/story.js): owner profile 조회→user ID→`reels[user_id]` 구조. 라이선스 재사용을 전제로 하지 않았으며 코드 복사 없음.
