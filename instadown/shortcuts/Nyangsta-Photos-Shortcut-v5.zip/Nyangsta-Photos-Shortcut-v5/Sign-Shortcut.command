#!/bin/zsh
set -euo pipefail

if [[ "$(/usr/bin/uname -s)" != Darwin ]]; then
  print -u2 '이 서명 준비 도구는 Mac에서 실행하세요.'
  exit 1
fi
ns5_kit=${0:A:h}
ns5_input="$ns5_kit/Instagram-Save-Photos-UNSIGNED.shortcut"
if [[ ! -f "$ns5_input" || -L "$ns5_input" ]]; then
  print -u2 '오류: 압축을 푼 폴더의 unsigned 단축어 파일을 찾지 못했습니다.'
  exit 1
fi
ns5_hash=$(/usr/bin/shasum -a 256 "$ns5_input")
if [[ "${ns5_hash%% *}" != '6a574df14bd6796293ec261d8b98cf9a54ce20abbf901cd68ae10cafb21b5f3f' ]]; then
  print -u2 '오류: 단축어가 수정본 5 준비본과 다릅니다. ZIP을 다시 받아 주세요.'
  exit 1
fi
ns5_out=$(/usr/bin/mktemp -d "$HOME/Downloads/NS5-Signed.XXXXXX")
ns5_signed="$ns5_out/Instagram-Save-Photos-v5.shortcut"
print '냥스타저장 수정본 5의 공유용 서명을 준비합니다.'
print '서명 시 Apple 검증 서비스로 단축어 사본이 전송됩니다.'
if ! /usr/bin/shortcuts sign --mode anyone --input "$ns5_input" --output "$ns5_signed"; then
  print -u2 '서명 실패. 위 오류를 확인해 주세요. 단축어 설치는 완료되지 않았습니다.'
  exit 1
fi
if [[ ! -s "$ns5_signed" || -L "$ns5_signed" ]]; then
  print -u2 '오류: 서명 결과 파일을 확인하지 못했습니다.'
  exit 1
fi
print "서명 파일 준비 완료: $ns5_signed"
print '아직 설치되지 않았습니다. 열리는 단축어 앱에서 냥스타저장을 추가하세요.'
print '같은 이름의 기존 냥스타저장이 있으면 수정본으로 교체하세요.'
print 'iPhone에 동기화되지 않으면 위 파일을 AirDrop으로 보내 추가하세요.'
print '방금 오류가 났던 링크의 공유 메뉴에서 냥스타저장을 실행하고 사진 앱에 저장됐는지 확인하세요.'
if ! /usr/bin/open "$ns5_signed"; then
  print '자동 열기에 실패했습니다. 위 서명 파일을 Finder에서 열어 주세요.'
fi
