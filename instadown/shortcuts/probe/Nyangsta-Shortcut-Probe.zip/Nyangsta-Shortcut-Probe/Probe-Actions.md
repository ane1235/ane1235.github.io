# 냥스타저장 진단 2 — 동작 목록

별도 unsigned 진단입니다. 기존 냥스타저장 단축어를 변경하지 않습니다.
Apple 서명·가져오기·iPhone/iPad 실행 호환성은 이 생성 작업으로 검증되지 않습니다.
abc 비교를 먼저 실행하고 통과했을 때만 개인정보 없는 고정 샘플 3개를 GET합니다.
샘플마다 짧은 해시 일치/불일치·타입·크기를 표시하고 전체 진단 텍스트를 클립보드에 복사합니다.
abc 실패 때도 전체 해시를 클립보드에 복사한 뒤 네트워크 없이 중단합니다.
Photos 쓰기·파일 앱 저장·Instagram 조회·공유 입력·쿠키·텔레메트리 동작이 없습니다.
클립보드의 기존 내용은 진단 텍스트로 바뀝니다. Local Only는 꺼져 있어 Universal Clipboard 공유가 가능하지만 보장하지 않습니다.
타입·크기는 Content Graph 관측값입니다. 원시 HTTP 바이트나 Photos 저장 성공의 증거가 아닙니다.
sample.bin 대조군은 이름과 MIME을 함께 바꾸므로 MIME 하나의 효과를 분리하지 않습니다.

매개변수 근거: viticci/shortcuts-playground-plugin의 2026-06-13 macOS 27/iOS 27 Simulator 메타데이터.
확인한 upstream commit: 2de03bffe4ce8802e06d184931d9e4ec366a2ef2 (2026-06-15).
https://github.com/viticci/shortcuts-playground-plugin/blob/2de03bffe4ce8802e06d184931d9e4ec366a2ef2/codex/skills/shortcuts-playground/data/toolkit-v78-first-party-parameter-keys.json
Apple의 클립보드 동작과 Local Only 설명: https://support.apple.com/en-sg/guide/shortcuts/apd081d9d61f/ios
이 자료는 사용자의 iOS 버전에서 실행된다는 보장이 아닙니다.

| 순서 | 출력 이름 | 동작 |
|---:|---|---|
| 1 | 검사문자열 | 네트워크 없이 검사할 텍스트 abc |
| 2 | 문자열수신해시 | [검사문자열]의 SHA256 |
| 3 | 문자열기대해시 | abc의 알려진 SHA256 기대값 |
| 4 | 문자열수신해시텍스트 | [문자열수신해시]를 텍스트로 변환 |
| 5 | 문자열비교 | [문자열수신해시텍스트]가 [문자열기대해시]와 같음 |
| 6 | 문자열비교-otherwise | 그렇지 않으면 |
| 7 | 문자열실패보고서 | abc 기대/수신 해시를 포함한 실패 보고서 |
| 8 | 문자열실패복사 | [문자열실패보고서] 전체 진단 텍스트를 클립보드에 복사 |
| 9 | 문자열실패 | 짧은 abc 실패 안내; 전체 해시는 클립보드에 있음 |
| 10 | 문자열실패중단 | 출력 없이 중단 |
| 11 | 문자열비교-end | 조건문 종료 |
| 12 | sample.jpg수신 | https://ane1235.github.io/instadown/shortcuts/probe/sample.jpg 고정 주소를 GET |
| 13 | sample.jpg해시 | [sample.jpg수신]의 SHA256 |
| 14 | sample.jpg타입 | [sample.jpg수신]의 콘텐츠 타입 관측 |
| 15 | sample.jpg크기 | [sample.jpg수신]의 File Size 관측 |
| 16 | sample.jpg기대해시 | 고정 샘플의 SHA256 기대값 |
| 17 | sample.jpg해시텍스트 | [sample.jpg해시]를 텍스트로 변환 |
| 18 | sample.jpg비교 | [sample.jpg해시텍스트]가 [sample.jpg기대해시]와 같음 |
| 19 | sample.jpg일치알림 | 해시 일치·타입·크기만 짧게 표시 |
| 20 | sample.jpg비교-otherwise | 그렇지 않으면 |
| 21 | sample.jpg불일치알림 | 해시 불일치·타입·크기만 짧게 표시 |
| 22 | sample.jpg비교-end | 조건문 종료 |
| 23 | sample.mp4수신 | https://ane1235.github.io/instadown/shortcuts/probe/sample.mp4 고정 주소를 GET |
| 24 | sample.mp4해시 | [sample.mp4수신]의 SHA256 |
| 25 | sample.mp4타입 | [sample.mp4수신]의 콘텐츠 타입 관측 |
| 26 | sample.mp4크기 | [sample.mp4수신]의 File Size 관측 |
| 27 | sample.mp4기대해시 | 고정 샘플의 SHA256 기대값 |
| 28 | sample.mp4해시텍스트 | [sample.mp4해시]를 텍스트로 변환 |
| 29 | sample.mp4비교 | [sample.mp4해시텍스트]가 [sample.mp4기대해시]와 같음 |
| 30 | sample.mp4일치알림 | 해시 일치·타입·크기만 짧게 표시 |
| 31 | sample.mp4비교-otherwise | 그렇지 않으면 |
| 32 | sample.mp4불일치알림 | 해시 불일치·타입·크기만 짧게 표시 |
| 33 | sample.mp4비교-end | 조건문 종료 |
| 34 | sample.bin수신 | https://ane1235.github.io/instadown/shortcuts/probe/sample.bin 고정 주소를 GET |
| 35 | sample.bin해시 | [sample.bin수신]의 SHA256 |
| 36 | sample.bin타입 | [sample.bin수신]의 콘텐츠 타입 관측 |
| 37 | sample.bin크기 | [sample.bin수신]의 File Size 관측 |
| 38 | sample.bin기대해시 | 고정 샘플의 SHA256 기대값 |
| 39 | sample.bin해시텍스트 | [sample.bin해시]를 텍스트로 변환 |
| 40 | sample.bin비교 | [sample.bin해시텍스트]가 [sample.bin기대해시]와 같음 |
| 41 | sample.bin일치알림 | 해시 일치·타입·크기만 짧게 표시 |
| 42 | sample.bin비교-otherwise | 그렇지 않으면 |
| 43 | sample.bin불일치알림 | 해시 불일치·타입·크기만 짧게 표시 |
| 44 | sample.bin비교-end | 조건문 종료 |
| 45 | 전체보고서 | abc와 세 샘플의 기대/관측 해시·타입·크기 전체 보고서 |
| 46 | 전체보고서복사 | [전체보고서] 전체 진단 텍스트를 클립보드에 복사 |
| 47 | 진단결과 | 전체 결과 복사 완료를 짧게 안내 |
| 48 | 진단종료 | 출력 없이 진단 종료 |
