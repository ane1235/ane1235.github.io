# 냥스타저장 진단 — 동작 목록

별도 unsigned 진단입니다. 기존 냥스타저장 단축어를 변경하지 않습니다.
Apple 서명·가져오기·iPhone/iPad 실행 호환성은 이 생성 작업으로 검증되지 않습니다.
abc 비교를 먼저 실행하고 통과했을 때만 개인정보 없는 고정 샘플 3개를 GET합니다.
Photos 쓰기·파일 앱 저장·Instagram 조회·공유 입력·쿠키·텔레메트리 동작이 없습니다.
타입·크기는 Content Graph 관측값입니다. 원시 HTTP 바이트나 Photos 저장 성공의 증거가 아닙니다.
sample.bin 대조군은 이름과 MIME을 함께 바꾸므로 MIME 하나의 효과를 분리하지 않습니다.

매개변수 근거: viticci/shortcuts-playground-plugin의 2026-06-13 macOS 27/iOS 27 Simulator 메타데이터.
확인한 upstream commit: 2de03bffe4ce8802e06d184931d9e4ec366a2ef2 (2026-06-15).
https://github.com/viticci/shortcuts-playground-plugin/blob/2de03bffe4ce8802e06d184931d9e4ec366a2ef2/codex/skills/shortcuts-playground/data/toolkit-v78-first-party-parameter-keys.json
이 자료는 사용자의 iOS 버전에서 실행된다는 보장이 아닙니다.

| 순서 | 출력 이름 | 동작 |
|---:|---|---|
| 1 | 검사문자열 | 네트워크 없이 검사할 텍스트 abc |
| 2 | 문자열수신해시 | [검사문자열]의 SHA256 |
| 3 | 문자열기대해시 | abc의 알려진 SHA256 기대값 |
| 4 | 문자열수신해시텍스트 | [문자열수신해시]를 텍스트로 변환 |
| 5 | 문자열비교 | [문자열수신해시텍스트]가 [문자열기대해시]와 같음 |
| 6 | 문자열비교-otherwise | 그렇지 않으면: 진단값 표시 후 네트워크 없이 중단 |
| 7 | 문자열실패 | abc 기대/수신 해시를 표시 |
| 8 | 문자열실패중단 | 출력 없이 중단 |
| 9 | 문자열비교-end | abc 조건문 종료 |
| 10 | sample.jpg수신 | https://ane1235.github.io/instadown/shortcuts/probe/sample.jpg 고정 주소를 GET |
| 11 | sample.jpg해시 | [sample.jpg수신]의 SHA256 |
| 12 | sample.jpg타입 | [sample.jpg수신]의 콘텐츠 타입 관측 |
| 13 | sample.jpg크기 | [sample.jpg수신]의 File Size 관측 |
| 14 | sample.mp4수신 | https://ane1235.github.io/instadown/shortcuts/probe/sample.mp4 고정 주소를 GET |
| 15 | sample.mp4해시 | [sample.mp4수신]의 SHA256 |
| 16 | sample.mp4타입 | [sample.mp4수신]의 콘텐츠 타입 관측 |
| 17 | sample.mp4크기 | [sample.mp4수신]의 File Size 관측 |
| 18 | sample.bin수신 | https://ane1235.github.io/instadown/shortcuts/probe/sample.bin 고정 주소를 GET |
| 19 | sample.bin해시 | [sample.bin수신]의 SHA256 |
| 20 | sample.bin타입 | [sample.bin수신]의 콘텐츠 타입 관측 |
| 21 | sample.bin크기 | [sample.bin수신]의 File Size 관측 |
| 22 | 진단결과 | 세 샘플의 기대/관측 해시·타입·크기를 함께 표시 |
| 23 | 진단종료 | 출력 없이 진단 종료 |
