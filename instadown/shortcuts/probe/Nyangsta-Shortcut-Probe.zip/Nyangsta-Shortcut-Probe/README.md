# 냥스타저장 진단 2

이 패키지는 iPhone 사진 해시 오류의 원인을 확인하기 위한 별도 단축어입니다. 기존 **냥스타저장**의 최종 저장 위치는 **사진 라이브러리**이며 그대로 유지됩니다. 이 진단은 합성 샘플 세 개를 읽고 짧은 결과창으로 해시 일치 여부를 보여줍니다. 전체 진단 텍스트를 마지막에 클립보드로 복사합니다.

버전1의 긴 결과창에서 스크롤이 안 되는 문제를 해결하기 위한 수정본입니다. **냥스타저장 진단 2**라는 별도 이름으로 추가합니다. 기기에 나타난 이름의 끝에 **2**가 있는지 확인하세요.

## Mac에서 준비하기

Mac 터미널에서 아래를 실행하면 새 준비 폴더에 버전2를 다운로드하고 서명합니다. 다운로드·압축 해제에 실패하면 다음 단계를 실행하지 않습니다. 기존 준비 폴더를 다시 사용하지 않습니다.

```sh
ns_dir=$(mktemp -d "$HOME/Downloads/NSP2.XXXXXX") &&
ns_base=https://ane1235.github.io/instadown/shortcuts/probe &&
curl -fL "$ns_base/Nyangsta-Shortcut-Probe.zip?v=2" \
  -o "$ns_dir/kit.zip" &&
ditto -x -k "$ns_dir/kit.zip" "$ns_dir" &&
/bin/zsh "$ns_dir/Nyangsta-Shortcut-Probe/Sign-Probe.command"
```

1. 열리는 단축어 앱에서 **냥스타저장 진단 2**를 추가합니다.
2. 같은 Apple 계정의 단축어 iCloud 동기화가 켜져 있다면 iPhone에도 나타납니다. 나타나지 않으면 터미널에 표시된 서명 파일을 AirDrop으로 iPhone에 보내 추가합니다.
3. iPhone **단축어 앱**에서 **냥스타저장 진단 2**를 실행합니다. 사이트 연결 요청이 나오면 `ane1235.github.io` 접근을 허용합니다.
4. 사진·영상·BIN의 짧은 결과창에서 각각 확인을 누릅니다. 마지막에 전체 결과가 클립보드에 복사됩니다.
5. 대화에 붙여넣어 전달합니다. Mac에서 바로 붙여넣을 수 없다면 iPhone의 메모 앱에 붙여넣고 공유할 수 있습니다. 동작 자체에서 오류가 나면 그 오류 문구와 동작 이름을 전달합니다.

ZIP 안의 `UNSIGNED.shortcut`은 설치 완료본이 아닙니다. Mac의 `shortcuts sign --mode anyone`으로 공유용 파일을 만듭니다. Apple 문서에 따르면 서명 시 검증을 위해 단축어 사본이 Apple에 전송될 수 있습니다. 이 단축어에는 개인 미디어나 로그인 정보가 없습니다. Mac 서명·가져오기 성공은 iPhone 실행 성공과 별개입니다.

## 관측 범위

- 로컬 텍스트 `abc`의 SHA256과 비교 조건을 먼저 확인합니다.
- 공개 합성 JPEG·MP4·JPEG와 같은 바이트인 `.bin`을 각각 받아 타입·크기와 SHA256 일치 여부를 짧게 표시합니다. 64자리 기대·관측 해시는 전체 복사 결과에 포함합니다.
- 타입과 크기는 단축어가 인식한 콘텐츠의 관측값입니다. HTTP 원본 바이트를 직접 측정했다는 뜻은 아닙니다.
- `.jpg`와 `.bin`은 확장자와 MIME이 함께 다릅니다. 결과 차이만으로 MIME 하나를 원인으로 확정하지 않습니다.
- 샘플만 사용하므로 원래 Instagram 응답의 문제를 모두 재현하는 것은 아닙니다. 기존 사진 해시 오류의 원인은 아직 확정하지 않았습니다.
- 진단 텍스트 복사는 기존 클립보드 내용을 바꿉니다. 기기 설정에 따라 Handoff로 다른 Apple 기기에도 붙여넣을 수 있도록 허용합니다. 자동 서버 업로드·클립보드 읽기·Photos/Files 저장·Instagram 조회 동작은 없습니다.

## 출처와 호환성

2026-09-18 확인. Apple 문서는 동작 사이에서 콘텐츠 타입이 자동 변환될 수 있음을 설명하지만, JPEG 다운로드·해시의 바이트 보존을 보장하지는 않습니다. 버전2의 실제 기기 표시·클립보드 동작은 아직 확인하지 않았습니다.

- [Apple: Content Graph](https://support.apple.com/guide/shortcuts/the-content-graph-engine-apd4618db957/ios)
- [Apple: 명령줄 단축어와 서명](https://support.apple.com/guide/shortcuts-mac/run-shortcuts-from-the-command-line-apd455c82f02/mac)
- [Apple: Clipboard 동작](https://support.apple.com/en-sg/guide/shortcuts/apd081d9d61f/ios)

`Probe-Actions.md`에서 실행 동작 전체를 확인할 수 있습니다.
