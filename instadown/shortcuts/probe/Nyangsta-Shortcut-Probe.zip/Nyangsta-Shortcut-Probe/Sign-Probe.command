#!/bin/zsh
set -euo pipefail

if [[ "$(/usr/bin/uname -s)" != Darwin ]]; then
  print -u2 '이 준비 도구는 Mac에서 실행하세요.'
  exit 1
fi
ns_probe_kit=${0:A:h}
ns_probe_input="$ns_probe_kit/Instagram-Save-Probe-UNSIGNED.shortcut"
if [[ ! -f "$ns_probe_input" || -L "$ns_probe_input" ]]; then
  print -u2 '오류: 압축을 푼 폴더의 단축어 파일을 찾지 못했습니다.'
  exit 1
fi
ns_probe_hash=$(/usr/bin/shasum -a 256 "$ns_probe_input")
if [[ "${ns_probe_hash%% *}" != '14af9c8e656a922d0f840837426841e55b319c9ed7f93acbf04ab570faeef9ee' ]]; then
  print -u2 '오류: 단축어 파일이 준비본과 다릅니다. ZIP을 다시 받아 주세요.'
  exit 1
fi
ns_probe_out=$(/usr/bin/mktemp -d "$HOME/Downloads/Nyangsta-Probe-Signed.XXXXXX")
ns_probe_signed="$ns_probe_out/Instagram-Save-Probe.shortcut"
print '냥스타저장 진단의 공유용 서명을 준비합니다.'
print 'Apple 검증 서비스로 진단 단축어 사본이 전송될 수 있습니다.'
if ! /usr/bin/shortcuts sign --mode anyone --input "$ns_probe_input" --output "$ns_probe_signed"; then
  print -u2 '서명 실패. 위 오류 문구를 확인해 주세요. 단축어 설치는 완료되지 않았습니다.'
  exit 1
fi
if [[ ! -s "$ns_probe_signed" || -L "$ns_probe_signed" ]]; then
  print -u2 '오류: 서명 결과 파일을 확인하지 못했습니다.'
  exit 1
fi
print "서명 파일 준비 완료: $ns_probe_signed"
print '단축어 앱에서 이름이 냥스타저장 진단인지 확인하고 추가하세요.'
print 'iPhone에 동기화되면 iPhone의 단축어 앱에서 실행하세요.'
print '동기화되지 않으면 위 파일을 AirDrop으로 iPhone에 보내 추가하세요.'
if ! /usr/bin/open "$ns_probe_signed"; then
  print '자동 열기에 실패했습니다. 위 서명 파일을 Finder에서 열어 주세요.'
fi
