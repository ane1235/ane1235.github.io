#!/bin/zsh
set -euo pipefail

if [[ "$(/usr/bin/uname -s)" != Darwin ]]; then
  print -u2 '이 서명 준비 도구는 Mac에서 실행하세요.'
  exit 1
fi
ns4_kit=${0:A:h}
ns4_input="$ns4_kit/Instagram-Save-Photos-UNSIGNED.shortcut"
if [[ ! -f "$ns4_input" || -L "$ns4_input" ]]; then
  print -u2 '오류: 압축을 푼 폴더의 unsigned 단축어 파일을 찾지 못했습니다.'
  exit 1
fi
ns4_hash=$(/usr/bin/shasum -a 256 "$ns4_input")
if [[ "${ns4_hash%% *}" != '3b873fccf4fb274ddaed357e7a6fafcfa26a5da4622bad348bcef20451fcb6d4' ]]; then
  print -u2 '오류: 단축어가 수정본 4 준비본과 다릅니다. ZIP을 다시 받아 주세요.'
  exit 1
fi
ns4_out=$(/usr/bin/mktemp -d "$HOME/Downloads/NS4-Signed.XXXXXX")
ns4_signed="$ns4_out/Instagram-Save-Photos-v4.shortcut"
print '냥스타저장 수정본 4의 공유용 서명을 준비합니다.'
print '서명 시 Apple 검증 서비스로 단축어 사본이 전송됩니다.'
if ! /usr/bin/shortcuts sign --mode anyone --input "$ns4_input" --output "$ns4_signed"; then
  print -u2 '서명 실패. 위 오류를 확인해 주세요. 단축어 설치는 완료되지 않았습니다.'
  exit 1
fi
if [[ ! -s "$ns4_signed" || -L "$ns4_signed" ]]; then
  print -u2 '오류: 서명 결과 파일을 확인하지 못했습니다.'
  exit 1
fi
print "서명 파일 준비 완료: $ns4_signed"
print '아직 설치되지 않았습니다. 열리는 단축어 앱에서 냥스타저장을 추가하세요.'
print '같은 이름의 기존 냥스타저장이 있으면 수정본으로 교체하세요.'
print 'iPhone에 동기화되지 않으면 위 파일을 AirDrop으로 보내 추가하세요.'
print '먼저 사진 한 장인 게시물에서 실행하고 사진 앱에 저장됐는지 확인하세요.'
if ! /usr/bin/open "$ns4_signed"; then
  print '자동 열기에 실패했습니다. 위 서명 파일을 Finder에서 열어 주세요.'
fi
